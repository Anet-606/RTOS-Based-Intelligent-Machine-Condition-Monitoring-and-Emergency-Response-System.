/*
 * Copyright 2022, NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "fsl_common.h"
#include "fsl_reset.h"

/*******************************************************************************
 * Definitions
 ******************************************************************************/
/* Component ID definition, used by tools. */
#ifndef FSL_COMPONENT_ID
#define FSL_COMPONENT_ID "platform.drivers.reset"
#endif

/*******************************************************************************
 * Variables
 ******************************************************************************/

/*******************************************************************************
 * Prototypes
 ******************************************************************************/

/*******************************************************************************
 * Code
 ******************************************************************************/

#if (defined(FSL_FEATURE_SOC_SYSCON_COUNT) && (FSL_FEATURE_SOC_SYSCON_COUNT > 0))

/*!
 * brief Assert reset to peripheral.
 *
 * Asserts reset signal to specified peripheral module.
 *
 * param peripheral Assert reset to this peripheral. The enum argument contains encoding of reset register
 *                   and reset bit position in the reset register.
 */
void RESET_SetPeripheralReset(reset_ip_name_t peripheral)
{
    const uint32_t regIndex = ((uint32_t)peripheral & 0xFFFF0000u) >> 16;
    const uint32_t bitPos   = ((uint32_t)peripheral & 0x0000FFFFu);
    const uint32_t bitMask  = 1UL << bitPos;
    volatile uint32_t *pResetCtrl;

    assert(bitPos < 32u);
    assert(regIndex < SYSCON_PRESETCTRLSET_COUNT);

    if (peripheral == kRST_None)
    {
        return;
    }

    /* reset register is in SYSCON */
    if (regIndex < SYSCON_PRESETCTRLSET_COUNT)
    {
        /* set bit */
        SYSCON->PRESETCTRLSET[regIndex] = bitMask;
        /* wait until it reads 0b1 */
        pResetCtrl = &(SYSCON->PRESETCTRL0);
        while (0u == ((uint32_t)pResetCtrl[regIndex] & bitMask))
        {
        }
    }
}

/*!
 * brief Clear reset to peripheral.
 *
 * Clears reset signal to specified peripheral module, allows it to operate.
 *
 * param peripheral Clear reset to this peripheral. The enum argument contains encoding of reset register
 *                   and reset bit position in the reset register.
 */
void RESET_ClearPeripheralReset(reset_ip_name_t peripheral)
{
    const uint32_t regIndex = ((uint32_t)peripheral & 0xFFFF0000u) >> 16;
    const uint32_t bitPos   = ((uint32_t)peripheral & 0x0000FFFFu);
    const uint32_t bitMask  = 1UL << bitPos;
    volatile uint32_t *pResetCtrl;

    assert(bitPos < 32u);
    assert(regIndex < SYSCON_PRESETCTRLSET_COUNT);

    if (peripheral == kRST_None)
    {
        return;
    }

    /* reset register is in SYSCON */
    if (regIndex < SYSCON_PRESETCTRLSET_COUNT)
    {
        /* clear bit */
        SYSCON->PRESETCTRLCLR[regIndex] = bitMask;
        /* wait until it reads 0b0 */
        pResetCtrl = &(SYSCON->PRESETCTRL0);
        while (bitMask == ((uint32_t)pResetCtrl[regIndex] & bitMask))
        {
        }
    }
}

/*!
 * brief Reset peripheral module.
 *
 * Reset peripheral module.
 *
 * param peripheral Peripheral to reset. The enum argument contains encoding of reset register
 *                   and reset bit position in the reset register.
 */
void RESET_PeripheralReset(reset_ip_name_t peripheral)
{
    if (peripheral == kRST_None)
    {
        return;
    }

    RESET_SetPeripheralReset(peripheral);
    RESET_ClearPeripheralReset(peripheral);
}

#endif /* FSL_FEATURE_SOC_SYSCON_COUNT || FSL_FEATURE_SOC_ASYNC_SYSCON_COUNT */
