source/semihost_hardfault.o source/semihost_hardfault.d: \
 ../source/semihost_hardfault.c \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\source\mcux_config.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\source\mcuxsdk_version.h
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\source\mcux_config.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\source\mcuxsdk_version.h:
