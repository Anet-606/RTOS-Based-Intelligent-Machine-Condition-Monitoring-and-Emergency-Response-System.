freertos/freertos-kernel/portable/GCC/ARM_CM33_NTZ/non_secure/mpu_wrappers_v2_asm.o \
 freertos/freertos-kernel/portable/GCC/ARM_CM33_NTZ/non_secure/mpu_wrappers_v2_asm.d: \
 ../freertos/freertos-kernel/portable/GCC/ARM_CM33_NTZ/non_secure/mpu_wrappers_v2_asm.c \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\source\mcux_config.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\source\mcuxsdk_version.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel-upstream\include/FreeRTOS.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel\template/FreeRTOSConfig.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\source/FreeRTOSConfig_Gen.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel-upstream\include/projdefs.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel-upstream\include/portable.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel-upstream\include/deprecated_definitions.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel\portable\GCC\ARM_CM33_NTZ\non_secure/portmacro.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel\portable\GCC\ARM_CM33_NTZ\non_secure/portmacrocommon.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel-upstream\include/mpu_wrappers.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel-upstream\include/task.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel-upstream\include/list.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel-upstream\include/queue.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel-upstream\include/task.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel-upstream\include/timers.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel-upstream\include/event_groups.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel-upstream\include/timers.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel-upstream\include/stream_buffer.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel-upstream\include/mpu_prototypes.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel-upstream\include/mpu_syscall_numbers.h
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\source\mcux_config.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\source\mcuxsdk_version.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel-upstream\include/FreeRTOS.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel\template/FreeRTOSConfig.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\source/FreeRTOSConfig_Gen.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel-upstream\include/projdefs.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel-upstream\include/portable.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel-upstream\include/deprecated_definitions.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel\portable\GCC\ARM_CM33_NTZ\non_secure/portmacro.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel\portable\GCC\ARM_CM33_NTZ\non_secure/portmacrocommon.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel-upstream\include/mpu_wrappers.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel-upstream\include/task.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel-upstream\include/list.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel-upstream\include/queue.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel-upstream\include/task.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel-upstream\include/timers.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel-upstream\include/event_groups.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel-upstream\include/timers.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel-upstream\include/stream_buffer.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel-upstream\include/mpu_prototypes.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel-upstream\include/mpu_syscall_numbers.h:
