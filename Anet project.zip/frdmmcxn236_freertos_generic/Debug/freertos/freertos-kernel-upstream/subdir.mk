################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../freertos/freertos-kernel-upstream/croutine.c \
../freertos/freertos-kernel-upstream/event_groups.c \
../freertos/freertos-kernel-upstream/list.c \
../freertos/freertos-kernel-upstream/queue.c \
../freertos/freertos-kernel-upstream/stream_buffer.c \
../freertos/freertos-kernel-upstream/tasks.c \
../freertos/freertos-kernel-upstream/timers.c 

C_DEPS += \
./freertos/freertos-kernel-upstream/croutine.d \
./freertos/freertos-kernel-upstream/event_groups.d \
./freertos/freertos-kernel-upstream/list.d \
./freertos/freertos-kernel-upstream/queue.d \
./freertos/freertos-kernel-upstream/stream_buffer.d \
./freertos/freertos-kernel-upstream/tasks.d \
./freertos/freertos-kernel-upstream/timers.d 

OBJS += \
./freertos/freertos-kernel-upstream/croutine.o \
./freertos/freertos-kernel-upstream/event_groups.o \
./freertos/freertos-kernel-upstream/list.o \
./freertos/freertos-kernel-upstream/queue.o \
./freertos/freertos-kernel-upstream/stream_buffer.o \
./freertos/freertos-kernel-upstream/tasks.o \
./freertos/freertos-kernel-upstream/timers.o 


# Each subdirectory must supply rules for building sources it contributes
freertos/freertos-kernel-upstream/%.o: ../freertos/freertos-kernel-upstream/%.c freertos/freertos-kernel-upstream/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: MCU C Compiler'
	arm-none-eabi-gcc -std=gnu99 -D__REDLIB__ -DSDK_I2C_BASED_COMPONENT_USED=1 -DCPU_MCXN236VDF -DCPU_MCXN236VDF_cm33 -DMCUXPRESSO_SDK -DSDK_DEBUGCONSOLE=1 -DMCUX_META_BUILD -DMCXN236_SERIES -DSDK_OS_FREE_RTOS -DCR_INTEGER_PRINTF -DPRINTF_FLOAT_ENABLE=0 -D__MCUXPRESSO -D__USE_CMSIS -DDEBUG -I"C:\Users\Rohan Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\drivers" -I"C:\Users\Rohan Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\CMSIS" -I"C:\Users\Rohan Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\CMSIS\m-profile" -I"C:\Users\Rohan Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device" -I"C:\Users\Rohan Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1" -I"C:\Users\Rohan Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\utilities" -I"C:\Users\Rohan Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\utilities\str" -I"C:\Users\Rohan Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\utilities\debug_console_lite" -I"C:\Users\Rohan Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\component\uart" -I"C:\Users\Rohan Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel-upstream\include" -I"C:\Users\Rohan Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel\include" -I"C:\Users\Rohan Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel\portable\GCC\ARM_CM33_NTZ\non_secure" -I"C:\Users\Rohan Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel\template" -I"C:\Users\Rohan Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel\template\ARM_CM33_3_priority_bits" -I"C:\Users\Rohan Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\source" -I"C:\Users\Rohan Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\board" -O0 -fno-common -g3 -gdwarf-4 -mcpu=cortex-m33 -c -ffunction-sections -fdata-sections -fno-builtin -imacros "C:\Users\Rohan Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\source\mcux_config.h" -imacros "C:\Users\Rohan Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\source\mcuxsdk_version.h" -fmerge-constants -fmacro-prefix-map="$(<D)/"= -mcpu=cortex-m33 -mfpu=fpv5-sp-d16 -mfloat-abi=hard -mthumb -D__REDLIB__ -fstack-usage -specs=redlib.specs -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@:%.o=%.o)" -MT"$(@:%.o=%.d)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


clean: clean-freertos-2f-freertos-2d-kernel-2d-upstream

clean-freertos-2f-freertos-2d-kernel-2d-upstream:
	-$(RM) ./freertos/freertos-kernel-upstream/croutine.d ./freertos/freertos-kernel-upstream/croutine.o ./freertos/freertos-kernel-upstream/event_groups.d ./freertos/freertos-kernel-upstream/event_groups.o ./freertos/freertos-kernel-upstream/list.d ./freertos/freertos-kernel-upstream/list.o ./freertos/freertos-kernel-upstream/queue.d ./freertos/freertos-kernel-upstream/queue.o ./freertos/freertos-kernel-upstream/stream_buffer.d ./freertos/freertos-kernel-upstream/stream_buffer.o ./freertos/freertos-kernel-upstream/tasks.d ./freertos/freertos-kernel-upstream/tasks.o ./freertos/freertos-kernel-upstream/timers.d ./freertos/freertos-kernel-upstream/timers.o

.PHONY: clean-freertos-2f-freertos-2d-kernel-2d-upstream

