freertos/freertos-kernel-upstream/stream_buffer.o \
 freertos/freertos-kernel-upstream/stream_buffer.d: \
 ../freertos/freertos-kernel-upstream/stream_buffer.c \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\source\mcux_config.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\source\mcuxsdk_version.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel-upstream\include/FreeRTOS.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel\template/FreeRTOSConfig.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\source/FreeRTOSConfig_Gen.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel-upstream\include/projdefs.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel-upstream\include/portable.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel-upstream\include/deprecated_definitions.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel\portable\GCC\ARM_CM33_NTZ\non_secure/portmacro.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel\portable\GCC\ARM_CM33_NTZ\non_secure/portmacrocommon.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel-upstream\include/mpu_wrappers.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel-upstream\include/task.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel-upstream\include/list.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel-upstream\include/stream_buffer.h
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\source\mcux_config.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\source\mcuxsdk_version.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel-upstream\include/FreeRTOS.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel\template/FreeRTOSConfig.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\source/FreeRTOSConfig_Gen.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel-upstream\include/projdefs.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel-upstream\include/portable.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel-upstream\include/deprecated_definitions.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel\portable\GCC\ARM_CM33_NTZ\non_secure/portmacro.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel\portable\GCC\ARM_CM33_NTZ\non_secure/portmacrocommon.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel-upstream\include/mpu_wrappers.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel-upstream\include/task.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel-upstream\include/list.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel-upstream\include/stream_buffer.h:
