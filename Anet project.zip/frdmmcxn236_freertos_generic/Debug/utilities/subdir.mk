################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../utilities/fsl_assert.c 

S_UPPER_SRCS += \
../utilities/fsl_memcpy.S \
../utilities/fsl_memset.S 

C_DEPS += \
./utilities/fsl_assert.d 

OBJS += \
./utilities/fsl_assert.o \
./utilities/fsl_memcpy.o \
./utilities/fsl_memset.o 


# Each subdirectory must supply rules for building sources it contributes
utilities/%.o: ../utilities/%.c utilities/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: MCU C Compiler'
	arm-none-eabi-gcc -std=gnu99 -D__REDLIB__ -DSDK_I2C_BASED_COMPONENT_USED=1 -DCPU_MCXN236VDF -DCPU_MCXN236VDF_cm33 -DMCUXPRESSO_SDK -DSDK_DEBUGCONSOLE=1 -DMCUX_META_BUILD -DMCXN236_SERIES -DSDK_OS_FREE_RTOS -DCR_INTEGER_PRINTF -DPRINTF_FLOAT_ENABLE=0 -D__MCUXPRESSO -D__USE_CMSIS -DDEBUG -I"C:\Users\Rohan Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\drivers" -I"C:\Users\Rohan Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\CMSIS" -I"C:\Users\Rohan Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\CMSIS\m-profile" -I"C:\Users\Rohan Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device" -I"C:\Users\Rohan Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1" -I"C:\Users\Rohan Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\utilities" -I"C:\Users\Rohan Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\utilities\str" -I"C:\Users\Rohan Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\utilities\debug_console_lite" -I"C:\Users\Rohan Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\component\uart" -I"C:\Users\Rohan Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel-upstream\include" -I"C:\Users\Rohan Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel\include" -I"C:\Users\Rohan Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel\portable\GCC\ARM_CM33_NTZ\non_secure" -I"C:\Users\Rohan Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel\template" -I"C:\Users\Rohan Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel\template\ARM_CM33_3_priority_bits" -I"C:\Users\Rohan Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\source" -I"C:\Users\Rohan Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\board" -O0 -fno-common -g3 -gdwarf-4 -mcpu=cortex-m33 -c -ffunction-sections -fdata-sections -fno-builtin -imacros "C:\Users\Rohan Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\source\mcux_config.h" -imacros "C:\Users\Rohan Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\source\mcuxsdk_version.h" -fmerge-constants -fmacro-prefix-map="$(<D)/"= -mcpu=cortex-m33 -mfpu=fpv5-sp-d16 -mfloat-abi=hard -mthumb -D__REDLIB__ -fstack-usage -specs=redlib.specs -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@:%.o=%.o)" -MT"$(@:%.o=%.d)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '

utilities/%.o: ../utilities/%.S utilities/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: MCU Assembler'
	arm-none-eabi-gcc -c -x assembler-with-cpp -D__REDLIB__ -I"C:\Users\Rohan Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\drivers" -I"C:\Users\Rohan Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\CMSIS" -I"C:\Users\Rohan Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\CMSIS\m-profile" -I"C:\Users\Rohan Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device" -I"C:\Users\Rohan Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1" -I"C:\Users\Rohan Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\utilities" -I"C:\Users\Rohan Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\utilities\str" -I"C:\Users\Rohan Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\utilities\debug_console_lite" -I"C:\Users\Rohan Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\component\uart" -I"C:\Users\Rohan Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel-upstream\include" -I"C:\Users\Rohan Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel\include" -I"C:\Users\Rohan Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel\portable\GCC\ARM_CM33_NTZ\non_secure" -I"C:\Users\Rohan Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel\template" -I"C:\Users\Rohan Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\freertos\freertos-kernel\template\ARM_CM33_3_priority_bits" -I"C:\Users\Rohan Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\source" -g3 -gdwarf-4 -mcpu=cortex-m33 -mfpu=fpv5-sp-d16 -mfloat-abi=hard -mthumb -D__REDLIB__ -specs=redlib.specs -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


clean: clean-utilities

clean-utilities:
	-$(RM) ./utilities/fsl_assert.d ./utilities/fsl_assert.o ./utilities/fsl_memcpy.o ./utilities/fsl_memset.o

.PHONY: clean-utilities

