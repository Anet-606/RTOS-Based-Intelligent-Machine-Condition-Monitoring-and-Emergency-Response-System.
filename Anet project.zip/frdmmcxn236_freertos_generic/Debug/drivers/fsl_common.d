drivers/fsl_common.o drivers/fsl_common.d: ../drivers/fsl_common.c \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\source\mcux_config.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\source\mcuxsdk_version.h \
 ../drivers/fsl_common.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device/fsl_device_registers.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device/MCXN236.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_ADC.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device/MCXN236_COMMON.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\CMSIS/core_cm33.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\CMSIS/cmsis_version.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\CMSIS/cmsis_compiler.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\CMSIS/cmsis_gcc.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\CMSIS/m-profile/armv8m_mpu.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device/system_MCXN236.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device/MCXN236_features.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_AHBSC.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_CAN.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_CDOG.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_CMC.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_CRC.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_CTIMER.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_DIGTMP.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_DM.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_DMA.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_EIM.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_ERM.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_EVTG.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_EWM.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_FLEXIO.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_FMU.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_FMUTEST.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_FREQME.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_GDET.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_GPIO.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_I2S.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_I3C.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_INPUTMUX.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_INTM.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_ITRC.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_LPCMP.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_LPI2C.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_LPSPI.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_LPTMR.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_LPUART.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_LP_FLEXCOMM.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_MRT.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_NPX.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_OSTIMER.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_OTPC.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_PDM.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_PINT.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_PKC.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_PORT.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_PUF.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_PWM.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_QDC.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_RTC.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_S50.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_SCG.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_SMARTDMA.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_SPC.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_SYSCON.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_SYSPM.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_TRDC.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_USBHS.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_USBHSDCD.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_USBNC.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_USBPHY.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_UTICK.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_VBAT.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_VREF.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_WUU.h \
 C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_WWDT.h \
 ../drivers/fsl_common_arm.h ../drivers/fsl_clock.h \
 ../drivers/fsl_reset.h
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\source\mcux_config.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\source\mcuxsdk_version.h:
../drivers/fsl_common.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device/fsl_device_registers.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device/MCXN236.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_ADC.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device/MCXN236_COMMON.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\CMSIS/core_cm33.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\CMSIS/cmsis_version.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\CMSIS/cmsis_compiler.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\CMSIS/cmsis_gcc.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\CMSIS/m-profile/armv8m_mpu.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device/system_MCXN236.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device/MCXN236_features.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_AHBSC.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_CAN.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_CDOG.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_CMC.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_CRC.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_CTIMER.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_DIGTMP.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_DM.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_DMA.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_EIM.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_ERM.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_EVTG.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_EWM.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_FLEXIO.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_FMU.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_FMUTEST.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_FREQME.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_GDET.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_GPIO.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_I2S.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_I3C.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_INPUTMUX.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_INTM.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_ITRC.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_LPCMP.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_LPI2C.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_LPSPI.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_LPTMR.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_LPUART.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_LP_FLEXCOMM.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_MRT.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_NPX.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_OSTIMER.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_OTPC.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_PDM.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_PINT.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_PKC.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_PORT.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_PUF.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_PWM.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_QDC.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_RTC.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_S50.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_SCG.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_SMARTDMA.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_SPC.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_SYSCON.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_SYSPM.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_TRDC.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_USBHS.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_USBHSDCD.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_USBNC.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_USBPHY.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_UTICK.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_VBAT.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_VREF.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_WUU.h:
C:\Users\Rohan\ Jose\Documents\MCUXpressoIDE_25.6.136\workspace\frdmmcxn236_freertos_generic\device\periph1/PERI_WWDT.h:
../drivers/fsl_common_arm.h:
../drivers/fsl_clock.h:
../drivers/fsl_reset.h:
