/*

 * ============================================================

 * RTOS-BASED INTELLIGENT MACHINE CONDITION MONITORING SYSTEM

 * ============================================================

 *

 * Board       : NXP FRDM-MCXN236

 * Processor   : ARM Cortex-M33

 * RTOS        : FreeRTOS

 *

 * STAGE 5F.1 - SENSOR COMMUNICATION FAULT SUPERVISION:

 * - Real FXLS8974CFR3 accelerometer acquisition

 * - Gravity-compensated dynamic vibration feature (mg)

 * - 20 ms periodic T1 acquisition

 * - T2 moving-average processing

 * - T3 vibration detection, hysteresis and accelerometer communication supervision

 * - T4 timestamped emergency-event queue and non-blocking LED indication

 * - Separate timestamped events for vibration, sensor-I2C and SW2 faults
 * - Per-source event-service latency statistics
 * - DWT-based FreeRTOS task runtime and CPU utilization profiling

 * - SW2 emergency interrupt

 * - Acoustic channel removed from this implementation

 *

 * I2C:

 * LPI2C2 / FLEXCOMM2, SDA=P4_0, SCL=P4_1, address=0x18

 *

 * Keep generated board, clock and pin-mux files unchanged.
 * Enable the documented runtime-statistics options in FreeRTOSConfig.h.

 */

/* ===================== FREERTOS HEADERS ==================== */

#include "FreeRTOS.h"

#include "task.h"

#include "queue.h"

/* ===================== NXP HEADERS ========================= */

#include "fsl_device_registers.h"

#include "fsl_common.h"

#include "fsl_clock.h"

#include "fsl_gpio.h"

#include "fsl_port.h"

#include "fsl_debug_console.h"

#include "board.h"

#include "clock_config.h"

#include "pin_mux.h"

#include "app.h"

/* ===================== STANDARD HEADERS ==================== */

#include <stdint.h>

#include <stdbool.h>

#include <stdio.h>

/* CMSIS Cortex-M33 DWT cycle-counter bit definitions. */

#ifndef CoreDebug_DEMCR_TRCENA_Msk

#define CoreDebug_DEMCR_TRCENA_Msk       (1UL << 24U)

#endif

#ifndef DWT_CTRL_CYCCNTENA_Msk

#define DWT_CTRL_CYCCNTENA_Msk           (1UL << 0U)

#endif

#ifndef DWT_CTRL_NOCYCCNT_Msk

#define DWT_CTRL_NOCYCCNT_Msk            (1UL << 25U)

#endif

/* ============================================================

 * 1. PROJECT CONFIGURATION

 * ============================================================ */

#define SAMPLE_PERIOD_MS                    20U

#define RAW_QUEUE_LENGTH                    10U

#define PROCESSED_QUEUE_LENGTH              10U

#define EMERGENCY_EVENT_QUEUE_LENGTH          16U

#define EMERGENCY_LED_DURATION_MS             1000U

/* Provisional bench-test thresholds; calibrate on the target machine. */

#define VIBRATION_TRIGGER_LIMIT_MG          150U

#define VIBRATION_RECOVERY_LIMIT_MG         100U

/* Persistence / recovery qualification. */

#define ABNORMAL_CONSECUTIVE_SAMPLES        3U

#define RECOVERY_CONSECUTIVE_SAMPLES        5U

/* Accelerometer communication fault qualification / recovery. */
#define SENSOR_COMM_FAILURE_CONSECUTIVE_SAMPLES  3U
#define SENSOR_COMM_RECOVERY_CONSECUTIVE_SAMPLES  5U

#define TASK_STACK_WORDS                   256U

#define DIAGNOSTICS_TASK_STACK_WORDS        512U

#define DIAGNOSTICS_PERIOD_MS               5000U

#define UART_LOG_BUFFER_COUNT               12U

#define UART_LOG_MESSAGE_LENGTH             256U

#define DIAGNOSTICS_TASK_PRIORITY           (tskIDLE_PRIORITY + 1U)

#define TASK_PRIORITY_SENSOR               (tskIDLE_PRIORITY + 2U)

#define TASK_PRIORITY_PROCESS              (tskIDLE_PRIORITY + 2U)

#define TASK_PRIORITY_DETECT               (tskIDLE_PRIORITY + 3U)

#define TASK_PRIORITY_FAULT                (tskIDLE_PRIORITY + 4U)

/* FXLS8974 register map and configuration. */

#define FXLS8974_ADDR_DEFAULT              0x18U

#define FXLS8974_ADDR_ALTERNATE            0x19U

#define FXLS8974_REG_OUT_X_LSB             0x04U

#define FXLS8974_REG_WHO_AM_I              0x13U

#define FXLS8974_REG_SENS_CONFIG1          0x15U

#define FXLS8974_REG_SENS_CONFIG2          0x16U

#define FXLS8974_REG_SENS_CONFIG3          0x17U

#define FXLS8974_WHO_AM_I_VALUE            0x86U

#define FXLS8974_ACTIVE_BIT                0x01U

#define FXLS8974_FSR_MASK                  0x06U

#define FXLS8974_WAKE_PM_MASK              0xC0U

#define FXLS8974_WAKE_ODR_100HZ            0x50U

#define ACCEL_LSB_PER_G                    1024L

/* Gravity low-pass update: gravity += (sample - gravity) / 8. */

#define GRAVITY_FILTER_SHIFT                3U

#define GRAVITY_FILTER_DIVISOR              (1L << GRAVITY_FILTER_SHIFT)

#define BASELINE_CALIBRATION_SAMPLES       50U

#define BASELINE_MIN_VALID_SAMPLES         45U

#define SW2_DEBOUNCE_MS                    200U

/* Individual emergency event source identifiers. */

#define EMERGENCY_SOURCE_SENSOR             1U

#define EMERGENCY_SOURCE_SW2                2U
#define EMERGENCY_SOURCE_SENSOR_COMM         3U

/* ============================================================

 * 2. DATA STRUCTURES

 * ============================================================ */

typedef struct

{

    uint32_t sampleNumber;

    int16_t accelXCounts;

    int16_t accelYCounts;

    int16_t accelZCounts;

    uint16_t vibrationMg;

    TickType_t timestamp;

    bool accelValid;

} SensorData_t;

typedef struct

{

    uint32_t sampleNumber;

    uint16_t vibrationFilteredMg;

    TickType_t timestamp;

    bool accelValid;

} ProcessedData_t;

typedef struct

{

    uint32_t source;

    uint32_t sourceCount;

    uint32_t eventCycle;

    TickType_t eventTick;

} EmergencyEvent_t;

typedef struct

{

    uint32_t count;

    uint32_t minimumUs;

    uint32_t maximumUs;

    uint64_t totalUs;

} EmergencyLatencyStats_t;

/* ============================================================

 * 3. GLOBAL RTOS OBJECTS

 * ============================================================ */

static QueueHandle_t xRawQueue = NULL;

static QueueHandle_t xProcessedQueue = NULL;

static QueueHandle_t xEmergencyQueue = NULL;

/* Task handles are retained for stack high-water inspection. */

static TaskHandle_t xT1TaskHandle = NULL;

static TaskHandle_t xT2TaskHandle = NULL;

static TaskHandle_t xT3TaskHandle = NULL;

static TaskHandle_t xT4TaskHandle = NULL;

static TaskHandle_t xT5TaskHandle = NULL;

/* Runtime-statistics snapshots are static to avoid consuming T5 stack/heap. */
#define RUNTIME_STATS_MAX_TASKS 12U

typedef struct
{
    TaskHandle_t taskHandle;
    uint32_t runtimeCounter;
} RuntimeTaskSnapshot_t;

static TaskStatus_t gRuntimeTaskStatus[RUNTIME_STATS_MAX_TASKS];
static RuntimeTaskSnapshot_t gPreviousRuntimeTasks[RUNTIME_STATS_MAX_TASKS];
static UBaseType_t gPreviousRuntimeTaskCount = 0U;
static uint32_t gPreviousRuntimeTotal = 0U;
static bool gRuntimeStatsBaselineReady = false;

/*

 * Runtime tasks enqueue text here; T5 is the only runtime UART writer.

 * The buffer is static so deferred logging does not consume FreeRTOS heap.

 */

static char gUartLogBuffer[UART_LOG_BUFFER_COUNT][UART_LOG_MESSAGE_LENGTH];

static char gUartLogTransmitBuffer[UART_LOG_MESSAGE_LENGTH];

static volatile uint32_t gUartLogHead = 0U;

static volatile uint32_t gUartLogTail = 0U;

static volatile uint32_t gUartLogCount = 0U;

static volatile uint32_t gUartLogPeakCount = 0U;

static volatile uint32_t gUartLogDropCount = 0U;

/* ============================================================

 * 3A. RUNTIME DIAGNOSTIC COUNTERS

 * ============================================================ */

/* Queue drop and peak counters are updated by their producer tasks. */

static volatile uint32_t gRawQueueDropCount = 0U;

static volatile uint32_t gProcessedQueueDropCount = 0U;

static volatile uint32_t gRawQueuePeakDepth = 0U;

static volatile uint32_t gProcessedQueuePeakDepth = 0U;

/* Sensor diagnostic counters, accumulated since startup. */

static volatile uint32_t gAccelerometerReadErrorCount = 0U;

static volatile uint32_t gAccelerometerSaturatedSampleCount = 0U;

/* T1 sample-start interval statistics, reported in periodic windows. */

static TickType_t gPreviousSampleStartTick = 0U;

static bool gHavePreviousSampleStartTick = false;

static volatile uint32_t gTimingIntervalCount = 0U;

static volatile uint32_t gTimingIntervalSumTicks = 0U;

static volatile TickType_t gTimingMinimumIntervalTicks = (TickType_t)~(TickType_t)0;

static volatile TickType_t gTimingMaximumIntervalTicks = 0U;

static volatile uint32_t gTimingLateIntervalCount = 0U;

static volatile uint32_t gTimingEarlyIntervalCount = 0U;

static volatile uint32_t gTimingExactIntervalCount = 0U;

/* ============================================================

 * 4. GLOBAL SENSOR / DIAGNOSTIC STATE

 * ============================================================ */

static uint8_t gAccelerometerAddress = FXLS8974_ADDR_DEFAULT;

static int32_t gBaselineX = 0;

static int32_t gBaselineY = 0;

static int32_t gBaselineZ = 0;

/* Slowly varying gravity estimate, in raw accelerometer counts. */

static int32_t gGravityX = 0;

static int32_t gGravityY = 0;

static int32_t gGravityZ = 0;

/* Event counters are cumulative since startup. */

static volatile uint32_t gSW2InterruptEvents = 0U;

static volatile uint32_t gSensorFaultEvents = 0U;

static volatile uint32_t gAccelerometerCommFaultEvents = 0U;

static volatile bool gSensorCommFaultActive = false;

static volatile uint32_t gEmergencyQueueDropCount = 0U;

/* Accessed only from the SW2 ISR. */

static volatile TickType_t gSW2LastInterruptTick = 0U;

static volatile bool gSW2HasPreviousInterrupt = false;

/* Accessed only by T4. */

static uint32_t gEmergencyResponses = 0U;

/* DWT timestamps are captured at event generation and event service. */

static volatile bool gLatencyDwtAvailable = false;

/* Updated by T4 and snapshotted/reset by T5 inside critical sections. */

static EmergencyLatencyStats_t gSensorLatencyStats = {0U, 0xFFFFFFFFUL, 0U, 0ULL};

static EmergencyLatencyStats_t gSensorCommLatencyStats = {0U, 0xFFFFFFFFUL, 0U, 0ULL};

static EmergencyLatencyStats_t gSW2LatencyStats = {0U, 0xFFFFFFFFUL, 0U, 0ULL};

/* ============================================================

 * 5. FREERTOS APPLICATION TICK HOOK

 * ============================================================ */

void vApplicationTickHook(void)

{

    /* Required by the existing NXP FreeRTOS configuration. */

}

/* ============================================================

 * 5A. HIGH-RESOLUTION LATENCY TIMER

 * ============================================================ */

/*

 * Enable the Cortex-M33 DWT cycle counter when this implementation provides

 * it. Some Cortex-M33 implementations can omit CYCCNT, so the application

 * retains a FreeRTOS tick-count fallback.

 */

static bool LatencyTimer_Init(void)

{

    uint32_t startCycles;

    volatile uint32_t spin;

    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;

    if ((DWT->CTRL & DWT_CTRL_NOCYCCNT_Msk) != 0U)

    {

        return false;

    }

    DWT->CYCCNT = 0U;

    DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;

    __DSB();

    __ISB();

    startCycles = DWT->CYCCNT;

    for (spin = 0U; spin < 32U; spin++)

    {

        __NOP();

    }

    return (DWT->CYCCNT != startCycles);

}

static uint32_t Latency_CyclesToMicroseconds(uint32_t elapsedCycles)

{

    if (SystemCoreClock == 0U)

    {

        return 0U;

    }

    return (uint32_t)(((uint64_t)elapsedCycles * 1000000ULL) /

                      (uint64_t)SystemCoreClock);

}

/*
 * FreeRTOS calls this accessor at task context switches. The DWT counter was
 * initialized once in main() before the scheduler and is shared with the
 * existing event-latency measurements. Never reset CYCCNT from this function.
 */
unsigned long ulApplicationGetRunTimeCounterValue(void)
{
    if (gLatencyDwtAvailable)
    {
        return (unsigned long)DWT->CYCCNT;
    }

    /* Do not substitute the 5 ms RTOS tick: it is too coarse for task profiling. */
    return 0U;
}

static bool RuntimeStats_FindPrevious(TaskHandle_t taskHandle,
                                      uint32_t *previousCounter)
{
    UBaseType_t i;

    for (i = 0U; i < gPreviousRuntimeTaskCount; i++)
    {
        if (gPreviousRuntimeTasks[i].taskHandle == taskHandle)
        {
            *previousCounter = gPreviousRuntimeTasks[i].runtimeCounter;
            return true;
        }
    }

    return false;
}

static uint32_t RuntimeStats_PercentTenths(uint32_t taskCycles,
                                           uint32_t totalCycles)
{
    uint64_t scaled;

    if (totalCycles == 0U)
    {
        return 0U;
    }

    scaled = ((uint64_t)taskCycles * 1000ULL) + ((uint64_t)totalCycles / 2ULL);
    scaled /= (uint64_t)totalCycles;

    if (scaled > 1000ULL)
    {
        scaled = 1000ULL;
    }

    return (uint32_t)scaled;
}

static void RuntimeStats_SaveSnapshot(UBaseType_t taskCount,
                                      uint32_t totalRuntime)
{
    UBaseType_t i;

    for (i = 0U; i < taskCount; i++)
    {
        gPreviousRuntimeTasks[i].taskHandle = gRuntimeTaskStatus[i].xHandle;
        gPreviousRuntimeTasks[i].runtimeCounter =
            (uint32_t)gRuntimeTaskStatus[i].ulRunTimeCounter;
    }

    gPreviousRuntimeTaskCount = taskCount;
    gPreviousRuntimeTotal = totalRuntime;
    gRuntimeStatsBaselineReady = true;
}

/*
 * Report task runtime shares for the interval since the previous snapshot.
 * Counter subtraction is intentionally unsigned to handle the 32-bit DWT
 * wraparound. A 5-second window is much shorter than the 28.6-second wrap at
 * the board's 150 MHz core clock.
 */
static void RuntimeStats_CaptureAndPrint(void)
{
    UBaseType_t expectedTaskCount;
    UBaseType_t taskCount;
    UBaseType_t i;
    configRUN_TIME_COUNTER_TYPE totalRuntime = 0U;
    uint32_t totalDelta;
    uint64_t nonIdleDelta;
    uint32_t previousCounter;
    uint32_t taskDelta;
    uint32_t t1Delta = 0U;
    uint32_t t2Delta = 0U;
    uint32_t t3Delta = 0U;
    uint32_t t4Delta = 0U;
    uint32_t t5Delta = 0U;
    uint32_t idleDelta = 0U;
    uint32_t otherDelta = 0U;
    uint32_t cpuTenths;
    uint32_t t1Tenths;
    uint32_t t2Tenths;
    uint32_t t3Tenths;
    uint32_t t4Tenths;
    uint32_t t5Tenths;
    uint32_t idleTenths;
    uint32_t otherTenths;
    TaskHandle_t idleHandle;

    if (!gLatencyDwtAvailable)
    {
        PRINTF("[CPU] Runtime profiling unavailable: DWT cycle counter is not available.\r\n");
        return;
    }

    expectedTaskCount = uxTaskGetNumberOfTasks();
    if (expectedTaskCount > RUNTIME_STATS_MAX_TASKS)
    {
        PRINTF("[CPU] Runtime profiling skipped: task count=%u exceeds snapshot capacity=%u.\r\n",
               (unsigned int)expectedTaskCount,
               (unsigned int)RUNTIME_STATS_MAX_TASKS);
        return;
    }

    taskCount = uxTaskGetSystemState(gRuntimeTaskStatus,
                                     RUNTIME_STATS_MAX_TASKS,
                                     &totalRuntime);
    if ((taskCount == 0U) || (taskCount > RUNTIME_STATS_MAX_TASKS))
    {
        PRINTF("[CPU] Runtime profiling skipped: uxTaskGetSystemState returned %u.\r\n",
               (unsigned int)taskCount);
        return;
    }

    if (!gRuntimeStatsBaselineReady)
    {
        RuntimeStats_SaveSnapshot(taskCount, (uint32_t)totalRuntime);
        PRINTF("[CPU] Runtime profiling baseline captured; percentages start in the next window.\r\n");
        return;
    }

    totalDelta = (uint32_t)((uint32_t)totalRuntime - gPreviousRuntimeTotal);
    if (totalDelta == 0U)
    {
        RuntimeStats_SaveSnapshot(taskCount, (uint32_t)totalRuntime);
        PRINTF("[CPU] Runtime profiling skipped: zero elapsed DWT cycles.\r\n");
        return;
    }

    idleHandle = xTaskGetIdleTaskHandle();

    for (i = 0U; i < taskCount; i++)
    {
        if (RuntimeStats_FindPrevious(gRuntimeTaskStatus[i].xHandle,
                                      &previousCounter))
        {
            taskDelta = (uint32_t)(
                (uint32_t)gRuntimeTaskStatus[i].ulRunTimeCounter - previousCounter);

            if (gRuntimeTaskStatus[i].xHandle == xT1TaskHandle)
            {
                t1Delta = taskDelta;
            }
            else if (gRuntimeTaskStatus[i].xHandle == xT2TaskHandle)
            {
                t2Delta = taskDelta;
            }
            else if (gRuntimeTaskStatus[i].xHandle == xT3TaskHandle)
            {
                t3Delta = taskDelta;
            }
            else if (gRuntimeTaskStatus[i].xHandle == xT4TaskHandle)
            {
                t4Delta = taskDelta;
            }
            else if (gRuntimeTaskStatus[i].xHandle == xT5TaskHandle)
            {
                t5Delta = taskDelta;
            }
            else if (gRuntimeTaskStatus[i].xHandle == idleHandle)
            {
                idleDelta += taskDelta;
            }
            else
            {
                /* Includes the FreeRTOS timer-service task and other system tasks. */
                otherDelta += taskDelta;
            }
        }
    }

    RuntimeStats_SaveSnapshot(taskCount, (uint32_t)totalRuntime);

    if (idleDelta > totalDelta)
    {
        idleDelta = totalDelta;
    }

    /* Sum all non-idle task runtime directly; do not infer load only from the
       idle task because configIDLE_SHOULD_YIELD is enabled in this project. */
    nonIdleDelta = (uint64_t)t1Delta + (uint64_t)t2Delta +
                   (uint64_t)t3Delta + (uint64_t)t4Delta +
                   (uint64_t)t5Delta + (uint64_t)otherDelta;
    if (nonIdleDelta > (uint64_t)totalDelta)
    {
        nonIdleDelta = (uint64_t)totalDelta;
    }
    cpuTenths = (uint32_t)((nonIdleDelta * 1000ULL +
                            ((uint64_t)totalDelta / 2ULL)) /
                           (uint64_t)totalDelta);
    t1Tenths = RuntimeStats_PercentTenths(t1Delta, totalDelta);
    t2Tenths = RuntimeStats_PercentTenths(t2Delta, totalDelta);
    t3Tenths = RuntimeStats_PercentTenths(t3Delta, totalDelta);
    t4Tenths = RuntimeStats_PercentTenths(t4Delta, totalDelta);
    t5Tenths = RuntimeStats_PercentTenths(t5Delta, totalDelta);
    idleTenths = RuntimeStats_PercentTenths(idleDelta, totalDelta);
    otherTenths = RuntimeStats_PercentTenths(otherDelta, totalDelta);

    PRINTF("[CPU] 5-second window: load=%u.%u%% | T1=%u.%u%% T2=%u.%u%% T3=%u.%u%% T4=%u.%u%% T5=%u.%u%% | IDLE=%u.%u%% OTHER=%u.%u%% | DWT cycles=%u\r\n",
           (unsigned int)(cpuTenths / 10U), (unsigned int)(cpuTenths % 10U),
           (unsigned int)(t1Tenths / 10U), (unsigned int)(t1Tenths % 10U),
           (unsigned int)(t2Tenths / 10U), (unsigned int)(t2Tenths % 10U),
           (unsigned int)(t3Tenths / 10U), (unsigned int)(t3Tenths % 10U),
           (unsigned int)(t4Tenths / 10U), (unsigned int)(t4Tenths % 10U),
           (unsigned int)(t5Tenths / 10U), (unsigned int)(t5Tenths % 10U),
           (unsigned int)(idleTenths / 10U), (unsigned int)(idleTenths % 10U),
           (unsigned int)(otherTenths / 10U), (unsigned int)(otherTenths % 10U),
           (unsigned int)totalDelta);
}

/* ============================================================

 * 6. DEFERRED UART LOGGING

 * ============================================================ */

static void Uart_Printf(const char *message)

{

    uint32_t i = 0U;

    bool queued = false;

    if (message == NULL)

    {

        return;

    }

    /* Copy only; never wait for UART transmission in T1-T4. */

    taskENTER_CRITICAL();

    if (gUartLogCount < UART_LOG_BUFFER_COUNT)

    {

        while ((i < (UART_LOG_MESSAGE_LENGTH - 1U)) && (message[i] != '\0'))

        {

            gUartLogBuffer[gUartLogTail][i] = message[i];

            i++;

        }

        gUartLogBuffer[gUartLogTail][i] = '\0';

        gUartLogTail = (gUartLogTail + 1U) % UART_LOG_BUFFER_COUNT;

        gUartLogCount++;

        if (gUartLogCount > gUartLogPeakCount)

        {

            gUartLogPeakCount = gUartLogCount;

        }

        queued = true;

    }

    else

    {

        gUartLogDropCount++;

    }

    taskEXIT_CRITICAL();

    /* Wake T5 efficiently when task notifications are enabled. */

#if defined(configUSE_TASK_NOTIFICATIONS) && (configUSE_TASK_NOTIFICATIONS == 1)

    if (queued && (xT5TaskHandle != NULL))

    {

        (void)xTaskNotifyGive(xT5TaskHandle);

    }

#else

    (void)queued;

#endif

}

/* ============================================================

 * 7. EMERGENCY EVENT QUEUE AND LATENCY STATISTICS

 * ============================================================ */

static void EmergencyQueue_RecordDropTask(void)

{

    taskENTER_CRITICAL();

    gEmergencyQueueDropCount++;

    taskEXIT_CRITICAL();

}

static void EmergencyQueue_RecordDropFromISR(void)

{

    UBaseType_t savedInterruptStatus = taskENTER_CRITICAL_FROM_ISR();

    gEmergencyQueueDropCount++;

    taskEXIT_CRITICAL_FROM_ISR(savedInterruptStatus);

}

/*

 * Each confirmed sensor anomaly becomes its own timestamped queue item.

 * A zero wait prevents T3 from blocking if the finite event queue is full.

 */

static bool RegisterSensorFaultEvent(uint32_t eventCycle, TickType_t eventTick)

{

    EmergencyEvent_t event;

    event.source = EMERGENCY_SOURCE_SENSOR;

    event.eventCycle = eventCycle;

    event.eventTick = eventTick;

    taskENTER_CRITICAL();

    gSensorFaultEvents++;

    event.sourceCount = gSensorFaultEvents;

    taskEXIT_CRITICAL();

    if (xQueueSend(xEmergencyQueue, &event, 0U) != pdPASS)

    {

        EmergencyQueue_RecordDropTask();

        Uart_Printf("[T3] WARNING: emergency event queue full; sensor event dropped.\r\n");

        return false;

    }

    return true;

}

/*
 * A communication fault is distinct from a vibration anomaly. It is queued
 * after T3 observes the configured number of consecutive invalid samples.
 */
static bool RegisterSensorCommFaultEvent(uint32_t eventCycle, TickType_t eventTick)

{

    EmergencyEvent_t event;

    uint32_t nextEventCount;

    event.source = EMERGENCY_SOURCE_SENSOR_COMM;

    event.eventCycle = eventCycle;

    event.eventTick = eventTick;

    taskENTER_CRITICAL();

    nextEventCount = gAccelerometerCommFaultEvents + 1U;

    taskEXIT_CRITICAL();

    event.sourceCount = nextEventCount;

    if (xQueueSend(xEmergencyQueue, &event, 0U) != pdPASS)

    {

        EmergencyQueue_RecordDropTask();

        Uart_Printf("[T3] WARNING: emergency queue full; accelerometer communication fault event not queued.\r\n");

        return false;

    }

    taskENTER_CRITICAL();

    gAccelerometerCommFaultEvents = nextEventCount;

    taskEXIT_CRITICAL();

    return true;

}

static uint32_t Latency_TicksToMicroseconds(TickType_t elapsedTicks)

{

    return (uint32_t)(((uint64_t)elapsedTicks * 1000000ULL) /

                      (uint64_t)configTICK_RATE_HZ);

}

static void EmergencyLatency_Record(uint32_t eventSource, uint32_t latencyUs)

{

    EmergencyLatencyStats_t *stats;

    if (eventSource == EMERGENCY_SOURCE_SENSOR)

    {

        stats = &gSensorLatencyStats;

    }

    else if (eventSource == EMERGENCY_SOURCE_SENSOR_COMM)

    {

        stats = &gSensorCommLatencyStats;

    }

    else

    {

        stats = &gSW2LatencyStats;

    }

    taskENTER_CRITICAL();

    if ((stats->count == 0U) || (latencyUs < stats->minimumUs))

    {

        stats->minimumUs = latencyUs;

    }

    if ((stats->count == 0U) || (latencyUs > stats->maximumUs))

    {

        stats->maximumUs = latencyUs;

    }

    stats->count++;

    stats->totalUs += (uint64_t)latencyUs;

    taskEXIT_CRITICAL();

}

/* ============================================================

 * 8. RUNTIME DIAGNOSTIC HELPERS

 * ============================================================ */

static void Diagnostics_UpdateQueuePeak(volatile uint32_t *peakDepth,

                                        UBaseType_t currentDepth)

{

    taskENTER_CRITICAL();

    if ((uint32_t)currentDepth > *peakDepth)

    {

        *peakDepth = (uint32_t)currentDepth;

    }

    taskEXIT_CRITICAL();

}

/* Measure queue depth before send because a higher-priority consumer may

 * run immediately after xQueueSend() and empty the queue before the sender

 * can inspect its post-send depth. */

static void Diagnostics_RecordQueueSendAttempt(QueueHandle_t queue,

                                                volatile uint32_t *peakDepth,

                                                uint32_t capacity)

{

    UBaseType_t depthBeforeSend = uxQueueMessagesWaiting(queue);

    UBaseType_t predictedDepth = depthBeforeSend;

    if ((uint32_t)depthBeforeSend < capacity)

    {

        predictedDepth++;

    }

    if ((uint32_t)predictedDepth > capacity)

    {

        predictedDepth = (UBaseType_t)capacity;

    }

    Diagnostics_UpdateQueuePeak(peakDepth, predictedDepth);

}

static void Diagnostics_RecordRawQueueDrop(void)

{

    taskENTER_CRITICAL();

    gRawQueueDropCount++;

    taskEXIT_CRITICAL();

}

static void Diagnostics_RecordProcessedQueueDrop(void)

{

    taskENTER_CRITICAL();

    gProcessedQueueDropCount++;

    taskEXIT_CRITICAL();

}

static void Diagnostics_RecordSampleStart(TickType_t sampleStartTick)

{

    if (gHavePreviousSampleStartTick)

    {

        TickType_t intervalTicks = (TickType_t)(sampleStartTick - gPreviousSampleStartTick);

        TickType_t expectedTicks = pdMS_TO_TICKS(SAMPLE_PERIOD_MS);

        taskENTER_CRITICAL();

        if (gTimingIntervalCount == 0U || intervalTicks < gTimingMinimumIntervalTicks)

        {

            gTimingMinimumIntervalTicks = intervalTicks;

        }

        if (intervalTicks > gTimingMaximumIntervalTicks)

        {

            gTimingMaximumIntervalTicks = intervalTicks;

        }

        gTimingIntervalCount++;

        gTimingIntervalSumTicks += (uint32_t)intervalTicks;

        if (intervalTicks < expectedTicks)

        {

            gTimingEarlyIntervalCount++;

        }

        else if (intervalTicks > expectedTicks)

        {

            gTimingLateIntervalCount++;

        }

        else

        {

            gTimingExactIntervalCount++;

        }

        taskEXIT_CRITICAL();

    }

    gPreviousSampleStartTick = sampleStartTick;

    gHavePreviousSampleStartTick = true;

}

/* ============================================================

 * 9. FXLS8974 I2C REGISTER ACCESS

 * ============================================================ */

static status_t FXLS8974_ReadRegister(uint8_t reg, uint8_t *value)

{

    return BOARD_Accel_I2C_Receive(

        gAccelerometerAddress,

        reg,

        1U,

        value,

        1U

    );

}

static status_t FXLS8974_WriteRegister(uint8_t reg, uint8_t value)

{

    return BOARD_Accel_I2C_Send(

        gAccelerometerAddress,

        reg,

        1U,

        value

    );

}

/* ============================================================

 * 10. ACCELEROMETER IDENTIFICATION

 * ============================================================ */

static bool FXLS8974_Detect(void)

{

    status_t status;

    uint8_t whoAmI = 0U;

    PRINTF("\r\n[ACCEL] Detecting FXLS8974...\r\n");

    gAccelerometerAddress = FXLS8974_ADDR_DEFAULT;

    status = FXLS8974_ReadRegister(FXLS8974_REG_WHO_AM_I, &whoAmI);

    if ((status != kStatus_Success) ||

        (whoAmI != FXLS8974_WHO_AM_I_VALUE))

    {

        gAccelerometerAddress = FXLS8974_ADDR_ALTERNATE;

        whoAmI = 0U;

        status = FXLS8974_ReadRegister(FXLS8974_REG_WHO_AM_I, &whoAmI);

    }

    if (status != kStatus_Success)

    {

        PRINTF("[ERROR] Accelerometer I2C read failed. Status=%d\r\n", (int)status);

        return false;

    }

    PRINTF("[ACCEL] WHO_AM_I = 0x%02X\r\n", (unsigned int)whoAmI);

    if (whoAmI != FXLS8974_WHO_AM_I_VALUE)

    {

        PRINTF("[ERROR] Unexpected sensor ID!\r\n");

        return false;

    }

    PRINTF("[ACCEL] FXLS8974 detected at 0x%02X\r\n",

           (unsigned int)gAccelerometerAddress);

    return true;

}

/* ============================================================

 * 11. ACCELEROMETER CONFIGURATION

 * ============================================================ */

static bool FXLS8974_Configure(void)

{

    status_t status;

    uint8_t config1;

    uint8_t config2;

    uint8_t config3;

    PRINTF("\r\n[ACCEL] Configuring sensor...\r\n");

    /* Enter standby before changing configuration. */

    status = FXLS8974_ReadRegister(FXLS8974_REG_SENS_CONFIG1, &config1);

    if (status != kStatus_Success)

    {

        PRINTF("[ERROR] SENS_CONFIG1 read failed.\r\n");

        return false;

    }

    config1 &= (uint8_t)(~FXLS8974_ACTIVE_BIT);

    status = FXLS8974_WriteRegister(FXLS8974_REG_SENS_CONFIG1, config1);

    if (status != kStatus_Success)

    {

        PRINTF("[ERROR] Sensor standby failed.\r\n");

        return false;

    }

    /* Select low-power mode while preserving unrelated bits. */

    status = FXLS8974_ReadRegister(FXLS8974_REG_SENS_CONFIG2, &config2);

    if (status != kStatus_Success)

    {

        PRINTF("[ERROR] SENS_CONFIG2 read failed.\r\n");

        return false;

    }

    config2 &= (uint8_t)(~FXLS8974_WAKE_PM_MASK);

    status = FXLS8974_WriteRegister(FXLS8974_REG_SENS_CONFIG2, config2);

    if (status != kStatus_Success)

    {

        PRINTF("[ERROR] SENS_CONFIG2 write failed.\r\n");

        return false;

    }

    /* WAKE ODR = 100 Hz; preserve lower nibble. */

    status = FXLS8974_ReadRegister(FXLS8974_REG_SENS_CONFIG3, &config3);

    if (status != kStatus_Success)

    {

        PRINTF("[ERROR] SENS_CONFIG3 read failed.\r\n");

        return false;

    }

    config3 = (uint8_t)((config3 & 0x0FU) | FXLS8974_WAKE_ODR_100HZ);

    status = FXLS8974_WriteRegister(FXLS8974_REG_SENS_CONFIG3, config3);

    if (status != kStatus_Success)

    {

        PRINTF("[ERROR] SENS_CONFIG3 write failed.\r\n");

        return false;

    }

    /* +/-2g full scale and ACTIVE=1. */

    config1 &= (uint8_t)(~FXLS8974_FSR_MASK);

    config1 |= FXLS8974_ACTIVE_BIT;

    status = FXLS8974_WriteRegister(FXLS8974_REG_SENS_CONFIG1, config1);

    if (status != kStatus_Success)

    {

        PRINTF("[ERROR] Sensor activation failed.\r\n");

        return false;

    }

    SDK_DelayAtLeastUs(100000U, SystemCoreClock);

    PRINTF("[ACCEL] Measurement range: +/-2g\r\n");

    PRINTF("[ACCEL] Output data rate: 100 Hz\r\n");

    PRINTF("[ACCEL] Operating mode: Low Power\r\n");

    PRINTF("[ACCEL] Sensor activated successfully.\r\n");

    return true;

}

/* ============================================================

 * 12. 12-BIT SIGNED DATA CONVERSION

 * ============================================================ */

static int16_t FXLS8974_ConvertToSigned(uint8_t lsb, uint8_t msb)

{

    uint16_t raw12;

    raw12 = (uint16_t)(((uint16_t)(msb & 0x0FU) << 8U) |

                       (uint16_t)lsb);

    if ((raw12 & 0x0800U) != 0U)

    {

        return (int16_t)((int32_t)raw12 - 4096L);

    }

    return (int16_t)raw12;

}

/* ============================================================

 * 13. READ X, Y AND Z ACCELERATION

 * ============================================================ */

static bool FXLS8974_ReadAcceleration(int16_t *x, int16_t *y, int16_t *z)

{

    status_t status;

    uint8_t data[6];

    status = BOARD_Accel_I2C_Receive(

        gAccelerometerAddress,

        FXLS8974_REG_OUT_X_LSB,

        1U,

        data,

        6U

    );

    if (status != kStatus_Success)

    {

        return false;

    }

    *x = FXLS8974_ConvertToSigned(data[0], data[1]);

    *y = FXLS8974_ConvertToSigned(data[2], data[3]);

    *z = FXLS8974_ConvertToSigned(data[4], data[5]);

    return true;

}

/* ============================================================

 * 14. STATIONARY BASELINE CALIBRATION

 * ============================================================ */

static bool FXLS8974_CalibrateBaseline(void)

{

    int32_t sumX = 0;

    int32_t sumY = 0;

    int32_t sumZ = 0;

    uint32_t validSamples = 0U;

    int16_t x;

    int16_t y;

    int16_t z;

    PRINTF("\r\n[CAL] Accelerometer baseline calibration\r\n");

    PRINTF("[CAL] Keep the board completely stationary.\r\n");

    for (uint32_t i = 0U; i < BASELINE_CALIBRATION_SAMPLES; i++)

    {

        if (FXLS8974_ReadAcceleration(&x, &y, &z))

        {

            sumX += (int32_t)x;

            sumY += (int32_t)y;

            sumZ += (int32_t)z;

            validSamples++;

        }

        SDK_DelayAtLeastUs(20000U, SystemCoreClock);

    }

    if (validSamples < BASELINE_MIN_VALID_SAMPLES)

    {

        PRINTF("[ERROR] Baseline calibration failed. Valid samples=%u\r\n",

               (unsigned int)validSamples);

        return false;

    }

    gBaselineX = sumX / (int32_t)validSamples;

    gBaselineY = sumY / (int32_t)validSamples;

    gBaselineZ = sumZ / (int32_t)validSamples;

    /* Seed the low-pass gravity tracker with the stationary average. */

    gGravityX = gBaselineX;

    gGravityY = gBaselineY;

    gGravityZ = gBaselineZ;

    PRINTF("[CAL] Valid calibration samples: %u\r\n",

           (unsigned int)validSamples);

    PRINTF("[CAL] Initial gravity X=%d, Y=%d, Z=%d counts\r\n",

           (int)gBaselineX, (int)gBaselineY, (int)gBaselineZ);

    PRINTF("[CAL] Baseline calibration completed.\r\n");

    return true;

}

/* ============================================================

 * 15. VIBRATION FEATURE CALCULATION

 * ============================================================ */

static uint32_t FXLS8974_Abs32(int32_t value)

{

    if (value < 0)

    {

        return (uint32_t)(-value);

    }

    return (uint32_t)value;

}

/*

 * Gravity-compensated vibration feature.

 *

 * The low-pass tracker follows the slowly changing gravity vector.

 * Subtracting the previous gravity estimate leaves the dynamic

 * acceleration component used as the vibration feature.

 *

 * At a 20 ms task period, the 1/8 update is a practical starting point

 * for rejecting slow orientation changes while retaining faster motion.

 * The feature is the largest absolute dynamic axis, converted to mg.

 */

static uint16_t FXLS8974_ComputeVibrationMg(int16_t x, int16_t y, int16_t z)

{

    int32_t dynamicX = (int32_t)x - gGravityX;

    int32_t dynamicY = (int32_t)y - gGravityY;

    int32_t dynamicZ = (int32_t)z - gGravityZ;

    uint32_t absX = FXLS8974_Abs32(dynamicX);

    uint32_t absY = FXLS8974_Abs32(dynamicY);

    uint32_t absZ = FXLS8974_Abs32(dynamicZ);

    uint32_t peakDynamicCounts = absX;

    uint32_t vibrationMg;

    /* Update gravity only after calculating this sample's dynamic part. */

    gGravityX += ((int32_t)x - gGravityX) / GRAVITY_FILTER_DIVISOR;

    gGravityY += ((int32_t)y - gGravityY) / GRAVITY_FILTER_DIVISOR;

    gGravityZ += ((int32_t)z - gGravityZ) / GRAVITY_FILTER_DIVISOR;

    if (absY > peakDynamicCounts)

    {

        peakDynamicCounts = absY;

    }

    if (absZ > peakDynamicCounts)

    {

        peakDynamicCounts = absZ;

    }

    vibrationMg = (peakDynamicCounts * 1000U) / (uint32_t)ACCEL_LSB_PER_G;

    if (vibrationMg > 65535U)

    {

        vibrationMg = 65535U;

    }

    return (uint16_t)vibrationMg;

}

/* The 12-bit output saturates at these signed limits in +/-2g mode. */

static bool FXLS8974_IsSaturated(int16_t x, int16_t y, int16_t z)

{

    return (x <= -2048) || (x >= 2047) ||

           (y <= -2048) || (y >= 2047) ||

           (z <= -2048) || (z >= 2047);

}

/* ============================================================

 * 16. BOARD LED INDICATORS

 * ============================================================ */

/* RGB LED is active-low: red+green=yellow, red only=emergency. */

static void Board_SetNormalIndicator(bool on)

{

    if (on)

    {

        LED_RED_ON();

        LED_GREEN_ON();

    }

    else

    {

        LED_RED_OFF();

        LED_GREEN_OFF();

    }

    LED_BLUE_OFF();

}

static void Board_SetEmergencyIndicator(bool on)

{

    if (on)

    {

        LED_RED_ON();

    }

    else

    {

        LED_RED_OFF();

    }

    LED_GREEN_OFF();

    LED_BLUE_OFF();

}

static void Board_IndicatorsInit(void)

{

    CLOCK_EnableClock(kCLOCK_Port4);

    GPIO_PortInit(GPIO4);

    PORT_SetPinMux(PORT4, BOARD_LED_RED_GPIO_PIN, kPORT_MuxAlt0);

    PORT_SetPinMux(PORT4, BOARD_LED_GREEN_GPIO_PIN, kPORT_MuxAlt0);

    PORT_SetPinMux(PORT4, BOARD_LED_BLUE_GPIO_PIN, kPORT_MuxAlt0);

    LED_RED_INIT(LOGIC_LED_OFF);

    LED_GREEN_INIT(LOGIC_LED_OFF);

    LED_BLUE_INIT(LOGIC_LED_OFF);

    Board_SetNormalIndicator(true);

}

/* ============================================================

 * 17. SW2 EMERGENCY BUTTON INITIALIZATION

 * ============================================================ */

static void SW2_InitHardware(void)

{

    const gpio_pin_config_t sw2InputConfig =

    {

        kGPIO_DigitalInput,

        0U

    };

    const port_pin_config_t sw2PortConfig =

    {

        .pullSelect = kPORT_PullUp,

        .pullValueSelect = kPORT_LowPullResistor,

        .slewRate = kPORT_FastSlewRate,

        .passiveFilterEnable = kPORT_PassiveFilterDisable,

        .openDrainEnable = kPORT_OpenDrainDisable,

        .driveStrength = kPORT_LowDriveStrength,

        .mux = kPORT_MuxAlt0,

        .inputBuffer = kPORT_InputBufferEnable,

        .invertInput = kPORT_InputNormal,

        .lockRegister = kPORT_UnlockRegister

    };

    CLOCK_EnableClock(kCLOCK_Port0);

    GPIO_PortInit(BOARD_SW2_GPIO);

    PORT_SetPinConfig(PORT0, BOARD_SW2_GPIO_PIN, &sw2PortConfig);

    GPIO_PinInit(BOARD_SW2_GPIO, BOARD_SW2_GPIO_PIN, &sw2InputConfig);

    GPIO_SetPinInterruptChannel(

        BOARD_SW2_GPIO,

        BOARD_SW2_GPIO_PIN,

        kGPIO_InterruptOutput0

    );

    GPIO_SetPinInterruptConfig(

        BOARD_SW2_GPIO,

        BOARD_SW2_GPIO_PIN,

        kGPIO_InterruptFallingEdge

    );

    GPIO_PinClearInterruptFlag(BOARD_SW2_GPIO, BOARD_SW2_GPIO_PIN);

    NVIC_DisableIRQ(BOARD_SW2_IRQ);

}

static void SW2_EnableInterrupt(void)

{

    NVIC_SetPriority(

        BOARD_SW2_IRQ,

        configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY

    );

    NVIC_ClearPendingIRQ(BOARD_SW2_IRQ);

    NVIC_EnableIRQ(BOARD_SW2_IRQ);

    Uart_Printf("[SW2] Emergency push-button interrupt enabled.\r\n");

}

/* ============================================================

 * 18. SW2 GPIO INTERRUPT SERVICE ROUTINE

 * ============================================================ */

/* SW2 and SW3 share GPIO00_IRQn. This handler only services SW2. */

void BOARD_SW2_IRQ_HANDLER(void)

{

    BaseType_t higherPriorityTaskWoken = pdFALSE;

    if (GPIO_PinGetInterruptFlag(BOARD_SW2_GPIO, BOARD_SW2_GPIO_PIN) != 0U)

    {

        GPIO_PinClearInterruptFlag(BOARD_SW2_GPIO, BOARD_SW2_GPIO_PIN);

        if (xEmergencyQueue != NULL)

        {

            TickType_t now = xTaskGetTickCountFromISR();

            TickType_t debounceTicks = pdMS_TO_TICKS(SW2_DEBOUNCE_MS);

            if ((!gSW2HasPreviousInterrupt) ||

                ((TickType_t)(now - gSW2LastInterruptTick) >= debounceTicks))

            {

                EmergencyEvent_t event;

                bool queued;

                gSW2HasPreviousInterrupt = true;

                gSW2LastInterruptTick = now;

                event.source = EMERGENCY_SOURCE_SW2;

                event.eventTick = now;

                event.eventCycle = gLatencyDwtAvailable ? DWT->CYCCNT : 0U;

                event.sourceCount = gSW2InterruptEvents + 1U;

                queued = (xQueueSendFromISR(

                    xEmergencyQueue,

                    &event,

                    &higherPriorityTaskWoken

                ) == pdPASS);

                if (queued)

                {

                    gSW2InterruptEvents = event.sourceCount;

                }

                else

                {

                    EmergencyQueue_RecordDropFromISR();

                }

            }

        }

    }

    portYIELD_FROM_ISR(higherPriorityTaskWoken);

}

/* ============================================================

 * 19. T1: SENSOR DATA ACQUISITION TASK

 * ============================================================ */

static void SensorAcquisitionTask(void *pvParameters)

{

    TickType_t lastWakeTime;

    uint32_t count = 0U;

    SensorData_t sample;

    TickType_t sampleStartTick;

    bool accelSaturated = false;

    char line[224];

    (void)pvParameters;

    Uart_Printf("[T1] Sensor Acquisition Task STARTED.\r\n");

    Uart_Printf("[T1] Sampling period: 20 ms (50 Hz).\r\n");

    Uart_Printf("[T1] Vibration feature: gravity-compensated peak dynamic axis.\r\n");

    /* Start the vTaskDelayUntil phase only after startup logging is queued. */

    lastWakeTime = xTaskGetTickCount();

    for (;;)

    {

        count++;

        sample.sampleNumber = count;

        sampleStartTick = xTaskGetTickCount();

        sample.timestamp = sampleStartTick;

        Diagnostics_RecordSampleStart(sampleStartTick);

        if (FXLS8974_ReadAcceleration(

                &sample.accelXCounts,

                &sample.accelYCounts,

                &sample.accelZCounts))

        {

            sample.accelValid = true;

            accelSaturated = FXLS8974_IsSaturated(

                sample.accelXCounts,

                sample.accelYCounts,

                sample.accelZCounts

            );

            sample.vibrationMg = FXLS8974_ComputeVibrationMg(

                sample.accelXCounts,

                sample.accelYCounts,

                sample.accelZCounts

            );

            if (accelSaturated)

            {

                taskENTER_CRITICAL();

                gAccelerometerSaturatedSampleCount++;

                taskEXIT_CRITICAL();

            }

        }

        else

        {

            sample.accelValid = false;

            sample.accelXCounts = 0;

            sample.accelYCounts = 0;

            sample.accelZCounts = 0;

            sample.vibrationMg = 0U;

            accelSaturated = false;

            taskENTER_CRITICAL();

            gAccelerometerReadErrorCount++;

            taskEXIT_CRITICAL();

            Uart_Printf("[T1] Warning: accelerometer read failed.\r\n");

        }

        Diagnostics_RecordQueueSendAttempt(

            xRawQueue,

            &gRawQueuePeakDepth,

            RAW_QUEUE_LENGTH

        );

        if (xQueueSend(xRawQueue, &sample, 0U) != pdPASS)

        {

            Diagnostics_RecordRawQueueDrop();

            Uart_Printf("[T1] Warning: sensor queue full.\r\n");

        }

        if ((count % 10U) == 0U)

        {

            (void)snprintf(

                line,

                sizeof(line),

                "[T1] sample=%u | X=%d Y=%d Z=%d counts | Dynamic vibration=%u mg | Sensor=%s | Range=%s\r\n",

                (unsigned int)sample.sampleNumber,

                (int)sample.accelXCounts,

                (int)sample.accelYCounts,

                (int)sample.accelZCounts,

                (unsigned int)sample.vibrationMg,

                sample.accelValid ? "OK" : "READ_ERROR",

                accelSaturated ? "CLIPPED" : "OK"

            );

            Uart_Printf(line);

        }

        vTaskDelayUntil(&lastWakeTime, pdMS_TO_TICKS(SAMPLE_PERIOD_MS));

    }

}

/* ============================================================

 * 20. T2: SENSOR DATA PROCESSING TASK

 * ============================================================ */

static void SensorProcessingTask(void *pvParameters)

{

    SensorData_t raw;

    ProcessedData_t feature;

    uint16_t previousVibration = 0U;

    bool havePreviousVibration = false;

    char line[144];

    (void)pvParameters;

    Uart_Printf("[T2] Sensor Processing Task STARTED.\r\n");

    for (;;)

    {

        if (xQueueReceive(xRawQueue, &raw, portMAX_DELAY) == pdPASS)

        {

            feature.sampleNumber = raw.sampleNumber;

            feature.timestamp = raw.timestamp;

            feature.accelValid = raw.accelValid;

            /* Two-sample moving average for vibration. */

            if (raw.accelValid)

            {

                if (!havePreviousVibration)

                {

                    feature.vibrationFilteredMg = raw.vibrationMg;

                    havePreviousVibration = true;

                }

                else

                {

                    feature.vibrationFilteredMg = (uint16_t)(

                        ((uint32_t)previousVibration + (uint32_t)raw.vibrationMg) / 2U

                    );

                }

                previousVibration = raw.vibrationMg;

            }

            else

            {

                feature.vibrationFilteredMg = 0U;

                havePreviousVibration = false;

            }

            Diagnostics_RecordQueueSendAttempt(

                xProcessedQueue,

                &gProcessedQueuePeakDepth,

                PROCESSED_QUEUE_LENGTH

            );

            if (xQueueSend(xProcessedQueue, &feature, 0U) != pdPASS)

            {

                Diagnostics_RecordProcessedQueueDrop();

                Uart_Printf("[T2] Warning: processed queue full.\r\n");

            }

            if ((feature.sampleNumber % 50U) == 0U)

            {

                (void)snprintf(

                    line,

                    sizeof(line),

                    "[T2] Processed sample=%u | Vibration=%u mg | Sensor=%s\r\n",

                    (unsigned int)feature.sampleNumber,

                    (unsigned int)feature.vibrationFilteredMg,

                    feature.accelValid ? "OK" : "READ_ERROR"

                );

                Uart_Printf(line);

            }

        }

    }

}

/* ============================================================

 * 21. T3: ANOMALY DETECTION TASK

 * ============================================================ */

/*

 * Accelerometer-only vibration fault qualification:

 * - Trigger after 3 consecutive processed samples > 150 mg.

 * - Remain latched while vibration is between 100 and 150 mg.

 * - Recover after 5 consecutive samples < 100 mg.

 *

 */

static void AnomalyDetectionTask(void *pvParameters)

{

    ProcessedData_t feature;

    bool faultLatched = false;

    uint8_t consecutiveAbnormal = 0U;

    uint8_t consecutiveRecovery = 0U;

    bool vibrationHigh;

    bool recovered;

    bool sensorCommFaultLatched = false;

    uint8_t consecutiveSensorReadFailures = 0U;

    uint8_t consecutiveSensorReadSuccesses = 0U;

    bool sensorCommEventQueued;

    uint32_t detectionCycle;

    TickType_t detectionTick;

    char line[176];

    (void)pvParameters;

    Uart_Printf("[T3] Anomaly Detection Task STARTED.\r\n");

    for (;;)

    {

        if (xQueueReceive(xProcessedQueue, &feature, portMAX_DELAY) == pdPASS)

        {

            /*
             * Supervise sensor communication independently from vibration.
             * Invalid samples never qualify as normal vibration or recovery.
             */
            if (!feature.accelValid)

            {

                consecutiveSensorReadSuccesses = 0U;

                if (!sensorCommFaultLatched)

                {

                    if (consecutiveSensorReadFailures < SENSOR_COMM_FAILURE_CONSECUTIVE_SAMPLES)

                    {

                        consecutiveSensorReadFailures++;

                    }

                    if (consecutiveSensorReadFailures >= SENSOR_COMM_FAILURE_CONSECUTIVE_SAMPLES)

                    {

                        detectionTick = xTaskGetTickCount();

                        detectionCycle = gLatencyDwtAvailable ? DWT->CYCCNT : 0U;

                        sensorCommEventQueued = RegisterSensorCommFaultEvent(detectionCycle, detectionTick);

                        if (sensorCommEventQueued)

                        {

                            sensorCommFaultLatched = true;

                            taskENTER_CRITICAL();

                            gSensorCommFaultActive = true;

                            taskEXIT_CRITICAL();

                            consecutiveSensorReadFailures = 0U;

                            Uart_Printf("\r\n[T3] ACCELEROMETER COMMUNICATION FAULT | three consecutive I2C reads failed. Emergency event queued.\r\n");

                        }

                    }

                }

            }

            else

            {

                consecutiveSensorReadFailures = 0U;

                if (sensorCommFaultLatched)

                {

                    if (consecutiveSensorReadSuccesses < SENSOR_COMM_RECOVERY_CONSECUTIVE_SAMPLES)

                    {

                        consecutiveSensorReadSuccesses++;

                    }

                    if (consecutiveSensorReadSuccesses >= SENSOR_COMM_RECOVERY_CONSECUTIVE_SAMPLES)

                    {

                        sensorCommFaultLatched = false;

                        taskENTER_CRITICAL();

                        gSensorCommFaultActive = false;

                        taskEXIT_CRITICAL();

                        consecutiveSensorReadSuccesses = 0U;

                        consecutiveSensorReadFailures = 0U;

                        Uart_Printf("[T3] ACCELEROMETER COMMUNICATION RESTORED | five consecutive successful reads confirmed.\r\n");

                    }

                }

            }

            vibrationHigh = feature.accelValid &&

                (!sensorCommFaultLatched) &&

                (feature.vibrationFilteredMg > VIBRATION_TRIGGER_LIMIT_MG);

            if (!faultLatched)

            {

                if (vibrationHigh)

                {

                    if (consecutiveAbnormal < ABNORMAL_CONSECUTIVE_SAMPLES)

                    {

                        consecutiveAbnormal++;

                    }

                }

                else

                {

                    consecutiveAbnormal = 0U;

                }

                if (consecutiveAbnormal >= ABNORMAL_CONSECUTIVE_SAMPLES)

                {

                    faultLatched = true;

                    consecutiveAbnormal = 0U;

                    consecutiveRecovery = 0U;

                    /* Timestamp immediately when T3 confirms the anomaly. */

                    detectionTick = xTaskGetTickCount();

                    detectionCycle = gLatencyDwtAvailable ? DWT->CYCCNT : 0U;

                    (void)snprintf(

                        line,

                        sizeof(line),

                        "\r\n[T3] VIBRATION ANOMALY LATCHED | sample=%u | filtered vibration=%u mg | limit=%u mg\r\n",

                        (unsigned int)feature.sampleNumber,

                        (unsigned int)feature.vibrationFilteredMg,

                        (unsigned int)VIBRATION_TRIGGER_LIMIT_MG

                    );

                    /* Queue the event before formatting logs so T4 can preempt promptly. */

                    (void)RegisterSensorFaultEvent(detectionCycle, detectionTick);

                    Uart_Printf(line);

                    Uart_Printf("[T3] Three consecutive abnormal samples confirmed.\r\n");

                    Uart_Printf("[T3] Emergency event queued for T4.\r\n");

                }

            }

            else

            {

                recovered = feature.accelValid &&

                    (!sensorCommFaultLatched) &&

                    (feature.vibrationFilteredMg < VIBRATION_RECOVERY_LIMIT_MG);

                if (recovered)

                {

                    if (consecutiveRecovery < RECOVERY_CONSECUTIVE_SAMPLES)

                    {

                        consecutiveRecovery++;

                    }

                }

                else

                {

                    consecutiveRecovery = 0U;

                }

                if (consecutiveRecovery >= RECOVERY_CONSECUTIVE_SAMPLES)

                {

                    faultLatched = false;

                    consecutiveRecovery = 0U;

                    consecutiveAbnormal = 0U;

                    Uart_Printf(

                        "[T3] VIBRATION CONDITION RECOVERED | five consecutive recovery samples confirmed.\r\n"

                    );

                }

            }

            if ((!faultLatched) && ((feature.sampleNumber % 50U) == 0U))

            {

                (void)snprintf(

                    line,

                    sizeof(line),

                    "[T3] NORMAL | sample=%u | vibration=%u mg | sensor=%s\r\n",

                    (unsigned int)feature.sampleNumber,

                    (unsigned int)feature.vibrationFilteredMg,

                    feature.accelValid ? "OK" : "READ_ERROR"

                );

                Uart_Printf(line);

            }

        }

    }

}

/* ============================================================

 * 22. T4: FAULT MANAGEMENT / EMERGENCY RESPONSE

 * ============================================================ */

static void FaultManagementTask(void *pvParameters)

{

    EmergencyEvent_t event;

    bool emergencyLedActive = false;

    bool ledWasActivatedForEvent;

    TickType_t ledStartTick = 0U;

    TickType_t nowTick;

    TickType_t elapsedTicks;

    TickType_t ledDurationTicks = pdMS_TO_TICKS(EMERGENCY_LED_DURATION_MS);

    TickType_t waitTicks;

    TickType_t serviceTick;

    uint32_t serviceCycle;

    uint32_t latencyUs;

    bool sensorSource;

    bool sensorCommSource;

    char line[224];

    (void)pvParameters;

    Uart_Printf("[T4] Fault Management Task STARTED.\r\n");

    SW2_EnableInterrupt();

    Board_SetNormalIndicator(true);

    for (;;)

    {

        /*

         * T4 does not sleep for the entire LED indication. It waits on the

         * event queue for either a new emergency event or the remaining LED

         * indication time, whichever happens first.

         */

        if (emergencyLedActive)

        {

            nowTick = xTaskGetTickCount();

            elapsedTicks = (TickType_t)(nowTick - ledStartTick);

            if (elapsedTicks >= ledDurationTicks)

            {

                Board_SetEmergencyIndicator(false);

                Board_SetNormalIndicator(true);

                emergencyLedActive = false;

                Uart_Printf("[T4] Emergency indication completed.\r\n");

                Uart_Printf("[T4] Awaiting next emergency event.\r\n\r\n");

                waitTicks = portMAX_DELAY;

            }

            else

            {

                waitTicks = (TickType_t)(ledDurationTicks - elapsedTicks);

            }

        }

        else

        {

            waitTicks = portMAX_DELAY;

        }

        if (xQueueReceive(xEmergencyQueue, &event, waitTicks) == pdPASS)

        {

            /* Re-check the deadline in case an event and timeout coincide. */

            if (emergencyLedActive)

            {

                nowTick = xTaskGetTickCount();

                elapsedTicks = (TickType_t)(nowTick - ledStartTick);

                if (elapsedTicks >= ledDurationTicks)

                {

                    Board_SetEmergencyIndicator(false);

                    Board_SetNormalIndicator(true);

                    emergencyLedActive = false;

                    Uart_Printf("[T4] Emergency indication completed.\r\n");

                }

            }

            ledWasActivatedForEvent = !emergencyLedActive;

            if (ledWasActivatedForEvent)

            {

                Board_SetNormalIndicator(false);

                Board_SetEmergencyIndicator(true);

                emergencyLedActive = true;

                /* Response timestamp is taken immediately after the LED GPIO update. */

                serviceTick = xTaskGetTickCount();

                serviceCycle = gLatencyDwtAvailable ? DWT->CYCCNT : 0U;

                ledStartTick = serviceTick;

            }

            else

            {

                /* The LED is already on: service promptly and extend its hold time. */

                serviceTick = xTaskGetTickCount();

                serviceCycle = gLatencyDwtAvailable ? DWT->CYCCNT : 0U;

                ledStartTick = serviceTick;

            }

            gEmergencyResponses++;

            (void)snprintf(

                line,

                sizeof(line),

                "\r\n[T4] Emergency event service number: %lu\r\n",

                (unsigned long)gEmergencyResponses

            );

            Uart_Printf(line);

            sensorSource = (event.source == EMERGENCY_SOURCE_SENSOR);

            sensorCommSource = (event.source == EMERGENCY_SOURCE_SENSOR_COMM);

            if (sensorSource)

            {

                (void)snprintf(

                    line,

                    sizeof(line),

                    "[T4] Event source: T3 SENSOR ANOMALY | confirmed faults=%lu\r\n",

                    (unsigned long)event.sourceCount

                );

                Uart_Printf(line);

            }

            else if (sensorCommSource)

            {

                (void)snprintf(

                    line,

                    sizeof(line),

                    "[T4] Event source: ACCELEROMETER I2C COMMUNICATION FAILURE | fault events=%lu\r\n",

                    (unsigned long)event.sourceCount

                );

                Uart_Printf(line);

            }

            else if (event.source == EMERGENCY_SOURCE_SW2)

            {

                (void)snprintf(

                    line,

                    sizeof(line),

                    "[T4] Event source: SW2 INTERRUPT | accepted presses=%lu\r\n",

                    (unsigned long)event.sourceCount

                );

                Uart_Printf(line);

            }

            else

            {

                Uart_Printf("[T4] WARNING: unknown emergency event source.\r\n");

            }

            if (ledWasActivatedForEvent)

            {

                Uart_Printf(

                    "[T4] EMERGENCY RESPONSE ACTIVATED | Machine condition: CRITICAL FAULT (LED indication)\r\n"

                );

                Uart_Printf("[T4] Red emergency LED ON.\r\n");

            }

            else

            {

                Uart_Printf(

                    "[T4] Additional emergency event serviced; red LED indication extended.\r\n"

                );

            }

            if (gLatencyDwtAvailable)

            {

                latencyUs = Latency_CyclesToMicroseconds(

                    (uint32_t)(serviceCycle - event.eventCycle)

                );

            }

            else

            {

                latencyUs = Latency_TicksToMicroseconds(

                    (TickType_t)(serviceTick - event.eventTick)

                );

            }

            EmergencyLatency_Record(event.source, latencyUs);

            if (gLatencyDwtAvailable)

            {

                if (sensorSource && ledWasActivatedForEvent)

                {

                    (void)snprintf(

                        line, sizeof(line),

                        "[LATENCY] T3 anomaly confirmation -> red LED ON: %lu us\r\n",

                        (unsigned long)latencyUs

                    );

                }

                else if (sensorCommSource && ledWasActivatedForEvent)

                {

                    (void)snprintf(

                        line, sizeof(line),

                        "[LATENCY] Accelerometer I2C fault confirmation -> red LED ON: %lu us\r\n",

                        (unsigned long)latencyUs

                    );

                }

                else if (sensorCommSource)

                {

                    (void)snprintf(

                        line, sizeof(line),

                        "[LATENCY] Accelerometer I2C fault -> T4 serviced while LED already ON: %lu us\r\n",

                        (unsigned long)latencyUs

                    );

                }

                else if ((event.source == EMERGENCY_SOURCE_SW2) && ledWasActivatedForEvent)

                {

                    (void)snprintf(

                        line, sizeof(line),

                        "[LATENCY] SW2 interrupt accepted -> red LED ON: %lu us\r\n",

                        (unsigned long)latencyUs

                    );

                }

                else if (sensorSource)

                {

                    (void)snprintf(

                        line, sizeof(line),

                        "[LATENCY] T3 anomaly -> T4 serviced while LED already ON: %lu us\r\n",

                        (unsigned long)latencyUs

                    );

                }

                else

                {

                    (void)snprintf(

                        line, sizeof(line),

                        "[LATENCY] SW2 accepted -> T4 serviced while LED already ON: %lu us\r\n",

                        (unsigned long)latencyUs

                    );

                }

            }

            else

            {

                (void)snprintf(

                    line, sizeof(line),

                    "[LATENCY] %s event -> T4 serviced: ~%lu us (FreeRTOS tick resolution: %lu Hz)%s\r\n",

                    sensorSource ? "T3 anomaly" : "SW2",

                    (unsigned long)latencyUs,

                    (unsigned long)configTICK_RATE_HZ,

                    ledWasActivatedForEvent ? "; LED activated" : "; LED already ON"

                );

            }

            Uart_Printf(line);

        }

        /* A queue timeout simply returns to the top, where the LED deadline is serviced. */

    }

}

/* ============================================================

 * 23. T5: PERIODIC SYSTEM DIAGNOSTICS TASK

 * ============================================================ */

static void DiagnosticsTask(void *pvParameters)

{

    uint32_t intervalCount;

    uint32_t intervalSumTicks;

    uint32_t earlyIntervalCount;

    uint32_t exactIntervalCount;

    uint32_t lateIntervalCount;

    TickType_t minimumIntervalTicks;

    TickType_t maximumIntervalTicks;

    uint32_t rawDrops;

    uint32_t processedDrops;

    uint32_t rawPeak;

    uint32_t processedPeak;

    uint32_t readErrors;

    uint32_t saturatedSamples;

    uint32_t rawCurrent;

    uint32_t processedCurrent;

    uint32_t uartLogCurrent;

    uint32_t uartLogPeak;

    uint32_t uartLogDrops;

    uint32_t emergencyQueueDrops;

    uint32_t emergencyQueueCurrent;

    uint32_t sensorLatencyAverageUs;

    uint32_t sensorCommLatencyAverageUs;

    uint32_t sw2LatencyAverageUs;

    uint32_t accelerometerCommFaultEvents;

    bool sensorCommFaultActiveSnapshot;

    EmergencyLatencyStats_t sensorLatencySnapshot;

    EmergencyLatencyStats_t sensorCommLatencySnapshot;

    EmergencyLatencyStats_t sw2LatencySnapshot;

    uint32_t averageIntervalMilliMs;

    uint32_t averageIntervalMs;

    uint32_t averageIntervalMsFraction;

    uint32_t minimumIntervalMs;

    uint32_t maximumIntervalMs;

    uint32_t expectedIntervalTicks;

    TickType_t lastDiagnosticsTick;

    TickType_t now;

    TickType_t elapsedTicks;

    TickType_t waitTicks;

    bool haveLogMessage;

    uint32_t i;

    char line[240];

    (void)pvParameters;

    Uart_Printf("[DIAG] Runtime diagnostics, CPU profiling and deferred UART logger STARTED.\r\n");

    RuntimeStats_CaptureAndPrint();

    lastDiagnosticsTick = xTaskGetTickCount();

    for (;;)

    {

        /*

         * T5 is the only runtime UART writer. T1-T4 only copy text into the

         * static ring buffer, so UART transmission cannot block those tasks.

         */

        haveLogMessage = false;

        taskENTER_CRITICAL();

        if (gUartLogCount > 0U)

        {

            for (i = 0U; i < UART_LOG_MESSAGE_LENGTH; i++)

            {

                gUartLogTransmitBuffer[i] = gUartLogBuffer[gUartLogHead][i];

                if (gUartLogTransmitBuffer[i] == '\0')

                {

                    break;

                }

            }

            gUartLogTransmitBuffer[UART_LOG_MESSAGE_LENGTH - 1U] = '\0';

            gUartLogHead = (gUartLogHead + 1U) % UART_LOG_BUFFER_COUNT;

            gUartLogCount--;

            haveLogMessage = true;

        }

        taskEXIT_CRITICAL();

        if (haveLogMessage)

        {

            PRINTF("%s", gUartLogTransmitBuffer);

            continue;

        }

        now = xTaskGetTickCount();

        elapsedTicks = (TickType_t)(now - lastDiagnosticsTick);

        expectedIntervalTicks = (uint32_t)pdMS_TO_TICKS(SAMPLE_PERIOD_MS);

        if (elapsedTicks >= pdMS_TO_TICKS(DIAGNOSTICS_PERIOD_MS))

        {

            lastDiagnosticsTick = now;

            /* Snapshot timing and lifetime counters atomically. */

            taskENTER_CRITICAL();

            intervalCount = gTimingIntervalCount;

            intervalSumTicks = gTimingIntervalSumTicks;

            earlyIntervalCount = gTimingEarlyIntervalCount;

            exactIntervalCount = gTimingExactIntervalCount;

            lateIntervalCount = gTimingLateIntervalCount;

            minimumIntervalTicks = gTimingMinimumIntervalTicks;

            maximumIntervalTicks = gTimingMaximumIntervalTicks;

            gTimingIntervalCount = 0U;

            gTimingIntervalSumTicks = 0U;

            gTimingEarlyIntervalCount = 0U;

            gTimingExactIntervalCount = 0U;

            gTimingLateIntervalCount = 0U;

            gTimingMinimumIntervalTicks = (TickType_t)~(TickType_t)0;

            gTimingMaximumIntervalTicks = 0U;

            rawDrops = gRawQueueDropCount;

            processedDrops = gProcessedQueueDropCount;

            rawPeak = gRawQueuePeakDepth;

            processedPeak = gProcessedQueuePeakDepth;

            readErrors = gAccelerometerReadErrorCount;

            saturatedSamples = gAccelerometerSaturatedSampleCount;

            uartLogCurrent = gUartLogCount;

            uartLogPeak = gUartLogPeakCount;

            uartLogDrops = gUartLogDropCount;

            emergencyQueueDrops = gEmergencyQueueDropCount;

            sensorLatencySnapshot = gSensorLatencyStats;

            sensorCommLatencySnapshot = gSensorCommLatencyStats;

            sw2LatencySnapshot = gSW2LatencyStats;

            accelerometerCommFaultEvents = gAccelerometerCommFaultEvents;

            sensorCommFaultActiveSnapshot = gSensorCommFaultActive;

            gSensorLatencyStats.count = 0U;

            gSensorLatencyStats.minimumUs = 0xFFFFFFFFUL;

            gSensorLatencyStats.maximumUs = 0U;

            gSensorLatencyStats.totalUs = 0ULL;

            gSensorCommLatencyStats.count = 0U;

            gSensorCommLatencyStats.minimumUs = 0xFFFFFFFFUL;

            gSensorCommLatencyStats.maximumUs = 0U;

            gSensorCommLatencyStats.totalUs = 0ULL;

            gSW2LatencyStats.count = 0U;

            gSW2LatencyStats.minimumUs = 0xFFFFFFFFUL;

            gSW2LatencyStats.maximumUs = 0U;

            gSW2LatencyStats.totalUs = 0ULL;

            taskEXIT_CRITICAL();

            rawCurrent = (uint32_t)uxQueueMessagesWaiting(xRawQueue);

            processedCurrent = (uint32_t)uxQueueMessagesWaiting(xProcessedQueue);

            emergencyQueueCurrent = (uint32_t)uxQueueMessagesWaiting(xEmergencyQueue);

            PRINTF("\r\n[DIAG] ===== 5-second runtime diagnostics =====\r\n");
            RuntimeStats_CaptureAndPrint();

            if (intervalCount > 0U)

            {

                /* Keep fractional milliseconds instead of truncating ticks first. */

                averageIntervalMilliMs = (uint32_t)(

                    ((uint64_t)intervalSumTicks * 1000000ULL) /

                    ((uint64_t)intervalCount * (uint64_t)configTICK_RATE_HZ)

                );

                averageIntervalMs = averageIntervalMilliMs / 1000U;

                averageIntervalMsFraction = averageIntervalMilliMs % 1000U;

                minimumIntervalMs = ((uint32_t)minimumIntervalTicks * 1000U) /

                                    (uint32_t)configTICK_RATE_HZ;

                maximumIntervalMs = ((uint32_t)maximumIntervalTicks * 1000U) /

                                    (uint32_t)configTICK_RATE_HZ;

                (void)snprintf(

                    line,

                    sizeof(line),

                    "[DIAG] T1 interval: n=%lu min=%lu ticks (%lu ms) max=%lu ticks (%lu ms) avg=%lu.%03lu ms expected=%lu ticks (%u ms at %lu Hz) | exact=%lu early=%lu late=%lu\r\n",

                    (unsigned long)intervalCount,

                    (unsigned long)minimumIntervalTicks,

                    (unsigned long)minimumIntervalMs,

                    (unsigned long)maximumIntervalTicks,

                    (unsigned long)maximumIntervalMs,

                    (unsigned long)averageIntervalMs,

                    (unsigned long)averageIntervalMsFraction,

                    (unsigned long)expectedIntervalTicks,

                    (unsigned int)SAMPLE_PERIOD_MS,

                    (unsigned long)configTICK_RATE_HZ,

                    (unsigned long)exactIntervalCount,

                    (unsigned long)earlyIntervalCount,

                    (unsigned long)lateIntervalCount

                );

                PRINTF("%s", line);

            }

            else

            {

                PRINTF("[DIAG] T1 timing: no interval samples in this window.\r\n");

            }

            (void)snprintf(

                line,

                sizeof(line),

                "[DIAG] Raw queue: current=%lu/%u peak=%lu/%u drops=%lu | Processed queue: current=%lu/%u peak=%lu/%u drops=%lu\r\n",

                (unsigned long)rawCurrent,

                (unsigned int)RAW_QUEUE_LENGTH,

                (unsigned long)rawPeak,

                (unsigned int)RAW_QUEUE_LENGTH,

                (unsigned long)rawDrops,

                (unsigned long)processedCurrent,

                (unsigned int)PROCESSED_QUEUE_LENGTH,

                (unsigned long)processedPeak,

                (unsigned int)PROCESSED_QUEUE_LENGTH,

                (unsigned long)processedDrops

            );

            PRINTF("%s", line);

            (void)snprintf(

                line,

                sizeof(line),

                "[DIAG] Emergency event queue: current=%lu/%u dropped_events=%lu\r\n",

                (unsigned long)emergencyQueueCurrent,

                (unsigned int)EMERGENCY_EVENT_QUEUE_LENGTH,

                (unsigned long)emergencyQueueDrops

            );

            PRINTF("%s", line);

            (void)snprintf(

                line,

                sizeof(line),

                "[DIAG] UART log ring: current=%lu/%u peak=%lu/%u dropped_messages=%lu\r\n",

                (unsigned long)uartLogCurrent,

                (unsigned int)UART_LOG_BUFFER_COUNT,

                (unsigned long)uartLogPeak,

                (unsigned int)UART_LOG_BUFFER_COUNT,

                (unsigned long)uartLogDrops

            );

            PRINTF("%s", line);

            (void)snprintf(

                line,

                sizeof(line),

                "[DIAG] Sensor totals: I2C read errors=%lu | communication fault events=%lu | saturated samples=%lu\r\n",

                (unsigned long)readErrors,

                (unsigned long)accelerometerCommFaultEvents,

                (unsigned long)saturatedSamples

            );

            PRINTF("%s", line);

            PRINTF("[DIAG] Accelerometer communication state: %s\r\n",

                   sensorCommFaultActiveSnapshot ? "FAULT_LATCHED" : "OK");

#if defined(configSUPPORT_DYNAMIC_ALLOCATION) && (configSUPPORT_DYNAMIC_ALLOCATION == 1)

            (void)snprintf(

                line,

                sizeof(line),

                "[DIAG] Heap: current free=%lu bytes | minimum-ever free=%lu bytes\r\n",

                (unsigned long)xPortGetFreeHeapSize(),

                (unsigned long)xPortGetMinimumEverFreeHeapSize()

            );

            PRINTF("%s", line);

#else

            PRINTF("[DIAG] Heap API unavailable: dynamic allocation support is not enabled in FreeRTOSConfig.h.\r\n");

#endif

#if defined(INCLUDE_uxTaskGetStackHighWaterMark) && (INCLUDE_uxTaskGetStackHighWaterMark == 1)

            (void)snprintf(

                line,

                sizeof(line),

                "[DIAG] Stack high-water (words remaining; higher is better): T1=%lu T2=%lu T3=%lu T4=%lu T5=%lu\r\n",

                (unsigned long)uxTaskGetStackHighWaterMark(xT1TaskHandle),

                (unsigned long)uxTaskGetStackHighWaterMark(xT2TaskHandle),

                (unsigned long)uxTaskGetStackHighWaterMark(xT3TaskHandle),

                (unsigned long)uxTaskGetStackHighWaterMark(xT4TaskHandle),

                (unsigned long)uxTaskGetStackHighWaterMark(xT5TaskHandle)

            );

            PRINTF("%s", line);

#else

            PRINTF("[DIAG] Stack high-water API disabled. Set INCLUDE_uxTaskGetStackHighWaterMark to 1 in FreeRTOSConfig.h to enable it.\r\n");

#endif

            if (sensorLatencySnapshot.count > 0U)

            {

                sensorLatencyAverageUs = (uint32_t)(

                    sensorLatencySnapshot.totalUs / sensorLatencySnapshot.count

                );

                (void)snprintf(

                    line,

                    sizeof(line),

                    "[DIAG] T3->T4 service latency: n=%lu avg=%lu us min=%lu us max=%lu us\r\n",

                    (unsigned long)sensorLatencySnapshot.count,

                    (unsigned long)sensorLatencyAverageUs,

                    (unsigned long)sensorLatencySnapshot.minimumUs,

                    (unsigned long)sensorLatencySnapshot.maximumUs

                );

                PRINTF("%s", line);

            }

            else

            {

                PRINTF("[DIAG] T3->T4 service latency: no events in this window.\r\n");

            }

            if (sensorCommLatencySnapshot.count > 0U)

            {

                sensorCommLatencyAverageUs = (uint32_t)(

                    sensorCommLatencySnapshot.totalUs / sensorCommLatencySnapshot.count

                );

                (void)snprintf(

                    line,

                    sizeof(line),

                    "[DIAG] Accelerometer I2C fault -> T4 latency: n=%lu avg=%lu us min=%lu us max=%lu us\r\n",

                    (unsigned long)sensorCommLatencySnapshot.count,

                    (unsigned long)sensorCommLatencyAverageUs,

                    (unsigned long)sensorCommLatencySnapshot.minimumUs,

                    (unsigned long)sensorCommLatencySnapshot.maximumUs

                );

                PRINTF("%s", line);

            }

            else

            {

                PRINTF("[DIAG] Accelerometer I2C fault -> T4 latency: no events in this window.\r\n");

            }

            if (sw2LatencySnapshot.count > 0U)

            {

                sw2LatencyAverageUs = (uint32_t)(

                    sw2LatencySnapshot.totalUs / sw2LatencySnapshot.count

                );

                (void)snprintf(

                    line,

                    sizeof(line),

                    "[DIAG] SW2->T4 service latency: n=%lu avg=%lu us min=%lu us max=%lu us\r\n",

                    (unsigned long)sw2LatencySnapshot.count,

                    (unsigned long)sw2LatencyAverageUs,

                    (unsigned long)sw2LatencySnapshot.minimumUs,

                    (unsigned long)sw2LatencySnapshot.maximumUs

                );

                PRINTF("%s", line);

            }

            else

            {

                PRINTF("[DIAG] SW2->T4 service latency: no events in this window.\r\n");

            }

            PRINTF("[DIAG] ========================================\r\n\r\n");

        }

        else

        {

            waitTicks = (TickType_t)(pdMS_TO_TICKS(DIAGNOSTICS_PERIOD_MS) - elapsedTicks);

#if defined(configUSE_TASK_NOTIFICATIONS) && (configUSE_TASK_NOTIFICATIONS == 1)

            (void)ulTaskNotifyTake(pdTRUE, waitTicks);

#else

            /* Compatibility fallback: service deferred logs every 10 ms. */

            (void)waitTicks;

            vTaskDelay(pdMS_TO_TICKS(10U));

#endif

        }

    }

}

/* ============================================================

 * 24. MAIN

 * ============================================================ */

int main(void)

{

    BaseType_t taskStatus;

    /* Generated board initialization: pins, clocks and debug UART. */

    BOARD_InitHardware();

    gLatencyDwtAvailable = LatencyTimer_Init();

    PRINTF("\r\n");

    PRINTF("============================================\r\n");

    PRINTF(" RTOS MACHINE CONDITION MONITORING SYSTEM\r\n");

    PRINTF(" FRDM-MCXN236 - STAGE 5F.1 SENSOR COMMUNICATION FAULT SUPERVISION\r\n");

    PRINTF("============================================\r\n");

    PRINTF("[MAIN] Board initialization completed.\r\n");

    if (gLatencyDwtAvailable)

    {

        PRINTF("[MAIN] Fault-response latency timer: DWT cycle counter at %u Hz.\r\n",

               (unsigned int)SystemCoreClock);

    }

    else

    {

        PRINTF("[MAIN] Fault-response latency timer: FreeRTOS tick fallback at %u Hz.\r\n",

               (unsigned int)configTICK_RATE_HZ);

    }

    Board_IndicatorsInit();

    /* Initialize the onboard accelerometer interface. */

    PRINTF("[MAIN] Initializing LPI2C2...\r\n");

    BOARD_Accel_I2C_Init();

    SDK_DelayAtLeastUs(20000U, SystemCoreClock);

    if (!FXLS8974_Detect())

    {

        PRINTF("[ERROR] FXLS8974 detection failed. Halting.\r\n");

        for (;;)

        {

        }

    }

    if (!FXLS8974_Configure())

    {

        PRINTF("[ERROR] FXLS8974 configuration failed. Halting.\r\n");

        for (;;)

        {

        }

    }

    /* Board must remain stationary during this calibration. */

    if (!FXLS8974_CalibrateBaseline())

    {

        PRINTF("[ERROR] Accelerometer baseline calibration failed.\r\n");

        for (;;)

        {

        }

    }

    /* Configure SW2 GPIO; enable its NVIC interrupt later in T4. */

    SW2_InitHardware();

    PRINTF("\r\n[MAIN] Creating FreeRTOS queues...\r\n");

    xRawQueue = xQueueCreate(

        RAW_QUEUE_LENGTH,

        sizeof(SensorData_t)

    );

    xProcessedQueue = xQueueCreate(

        PROCESSED_QUEUE_LENGTH,

        sizeof(ProcessedData_t)

    );

    PRINTF("[MAIN] Creating timestamped emergency event queue...\r\n");

    xEmergencyQueue = xQueueCreate(

        EMERGENCY_EVENT_QUEUE_LENGTH,

        sizeof(EmergencyEvent_t)

    );

    if ((xRawQueue == NULL) ||

        (xProcessedQueue == NULL) ||

        (xEmergencyQueue == NULL))

    {

        PRINTF("[ERROR] Failed to create RTOS objects. Check heap size.\r\n");

        for (;;)

        {

        }

    }

    taskStatus = xTaskCreate(

        SensorAcquisitionTask,

        "T1_Sensor",

        TASK_STACK_WORDS,

        NULL,

        TASK_PRIORITY_SENSOR,

        &xT1TaskHandle

    );

    if (taskStatus != pdPASS)

    {

        PRINTF("[ERROR] T1 task creation failed.\r\n");

        for (;;)

        {

        }

    }

    taskStatus = xTaskCreate(

        SensorProcessingTask,

        "T2_Process",

        TASK_STACK_WORDS,

        NULL,

        TASK_PRIORITY_PROCESS,

        &xT2TaskHandle

    );

    if (taskStatus != pdPASS)

    {

        PRINTF("[ERROR] T2 task creation failed.\r\n");

        for (;;)

        {

        }

    }

    taskStatus = xTaskCreate(

        AnomalyDetectionTask,

        "T3_Detect",

        TASK_STACK_WORDS,

        NULL,

        TASK_PRIORITY_DETECT,

        &xT3TaskHandle

    );

    if (taskStatus != pdPASS)

    {

        PRINTF("[ERROR] T3 task creation failed.\r\n");

        for (;;)

        {

        }

    }

    taskStatus = xTaskCreate(

        FaultManagementTask,

        "T4_Fault",

        TASK_STACK_WORDS,

        NULL,

        TASK_PRIORITY_FAULT,

        &xT4TaskHandle

    );

    if (taskStatus != pdPASS)

    {

        PRINTF("[ERROR] T4 task creation failed.\r\n");

        for (;;)

        {

        }

    }

    taskStatus = xTaskCreate(

        DiagnosticsTask,

        "T5_Diagnostics",

        DIAGNOSTICS_TASK_STACK_WORDS,

        NULL,

        DIAGNOSTICS_TASK_PRIORITY,

        &xT5TaskHandle

    );

    if (taskStatus != pdPASS)

    {

        PRINTF("[ERROR] T5 diagnostics task creation failed. Check heap size.\r\n");

        for (;;)

        {

        }

    }

    Board_SetNormalIndicator(true);

    PRINTF("\r\n============================================\r\n");

    PRINTF("[MAIN] Gravity-compensated accelerometer-only integration completed.\r\n");

    PRINTF("[MAIN] Raw queue capacity       : 10\r\n");

    PRINTF("[MAIN] Processed queue capacity : 10\r\n");

    PRINTF("[MAIN] Emergency event queue    : 16 timestamped events\r\n");

    PRINTF("[MAIN] T4 emergency LED         : non-blocking 1000 ms indication\r\n");

    PRINTF("[MAIN] T1 sampling period       : 20 ms\r\n");

    PRINTF("[MAIN] T1/T2 priority           : 2\r\n");

    PRINTF("[MAIN] T3 priority              : 3\r\n");

    PRINTF("[MAIN] T4 priority              : 4\r\n");

    PRINTF("[MAIN] T5 logger/diagnostics priority: 1\r\n");

    PRINTF("[MAIN] Diagnostics interval     : 5000 ms\r\n");

    PRINTF("[MAIN] UART logging              : deferred, nonblocking ring buffer\r\n");

    PRINTF("[MAIN] T1 timing measurement    : sample-start to sample-start\r\n");

    PRINTF("[MAIN] Timing bins               : exact / early / late\r\n");

    PRINTF("[MAIN] Vibration trigger        : >150 mg for 3 samples\r\n");

    PRINTF("[MAIN] Vibration recovery       : <100 mg for 5 samples\r\n");

    PRINTF("[MAIN] Gravity filter update    : 1/8 per sample\r\n");

    PRINTF("[MAIN] Sensor range diagnostic  : +/-2g clipping check\r\n");

    PRINTF("[MAIN] Sensor I2C fault trigger : 3 consecutive read failures\r\n");

    PRINTF("[MAIN] Sensor I2C fault recovery: 5 consecutive successful reads\r\n");

    PRINTF("[MAIN] Acoustic input           : not used\r\n");

    PRINTF("[MAIN] Emergency output         : onboard LED indication only\r\n");

    PRINTF("[MAIN] Queue diagnostics        : occupancy, peak depth, drop counts\r\n");

    PRINTF("[MAIN] Stack diagnostics        : enabled through FreeRTOSConfig.h\r\n");
    PRINTF("[MAIN] CPU profiling             : DWT runtime counter / 5-second task shares\r\n");

    PRINTF("[MAIN] Heap diagnostics         : current and minimum-ever free\r\n");

    PRINTF("============================================\r\n");

    PRINTF("[MAIN] Starting FreeRTOS scheduler...\r\n");

    vTaskStartScheduler();

    PRINTF("[ERROR] FreeRTOS scheduler returned. Check heap/configuration.\r\n");

    for (;;)

    {

    }

}
