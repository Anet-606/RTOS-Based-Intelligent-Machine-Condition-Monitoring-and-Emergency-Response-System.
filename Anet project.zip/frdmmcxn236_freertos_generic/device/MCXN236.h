/*
** ###################################################################
**     Processors:          MCXN236VDF
**                          MCXN236VKL
**                          MCXN236VNL
**                          MCXN236VPB
**
**     Compilers:           GNU C Compiler
**                          IAR ANSI C/C++ Compiler for ARM
**                          Keil ARM C/C++ Compiler
**                          MCUXpresso Compiler
**
**     Reference manual:    MCXN23XRM
**     Version:             rev. 2.0, 2024-10-29
**     Build:               b250521
**
**     Abstract:
**         CMSIS Peripheral Access Layer for MCXN236
**
**     Copyright 1997-2016 Freescale Semiconductor, Inc.
**     Copyright 2016-2025 NXP
**     SPDX-License-Identifier: BSD-3-Clause
**
**     http:                 www.nxp.com
**     mail:                 support@nxp.com
**
**     Revisions:
**     - rev. 1.0 (2023-10-01)
**         Initial version based on RM 1.2
**     - rev. 2.0 (2024-10-29)
**         Change the device header file from single flat file to multiple files based on peripherals,
**         each peripheral with dedicated header file located in periphN folder.
**
** ###################################################################
*/

/*!
 * @file MCXN236.h
 * @version 2.0
 * @date 2024-10-29
 * @brief CMSIS Peripheral Access Layer for MCXN236
 *
 * CMSIS Peripheral Access Layer for MCXN236
 */

#if !defined(MCXN236_H_)  /* Check if memory map has not been already included */
#define MCXN236_H_

/* IP Header Files List */
#include "PERI_ADC.h"
#include "PERI_AHBSC.h"
#include "PERI_CAN.h"
#include "PERI_CDOG.h"
#include "PERI_CMC.h"
#include "PERI_CRC.h"
#include "PERI_CTIMER.h"
#include "PERI_DIGTMP.h"
#include "PERI_DM.h"
#include "PERI_DMA.h"
#include "PERI_EIM.h"
#include "PERI_ERM.h"
#include "PERI_EVTG.h"
#include "PERI_EWM.h"
#include "PERI_FLEXIO.h"
#include "PERI_FMU.h"
#include "PERI_FMUTEST.h"
#include "PERI_FREQME.h"
#include "PERI_GDET.h"
#include "PERI_GPIO.h"
#include "PERI_I2S.h"
#include "PERI_I3C.h"
#include "PERI_INPUTMUX.h"
#include "PERI_INTM.h"
#include "PERI_ITRC.h"
#include "PERI_LPCMP.h"
#include "PERI_LPI2C.h"
#include "PERI_LPSPI.h"
#include "PERI_LPTMR.h"
#include "PERI_LPUART.h"
#include "PERI_LP_FLEXCOMM.h"
#include "PERI_MRT.h"
#include "PERI_NPX.h"
#include "PERI_OSTIMER.h"
#include "PERI_OTPC.h"
#include "PERI_PDM.h"
#include "PERI_PINT.h"
#include "PERI_PKC.h"
#include "PERI_PORT.h"
#include "PERI_PUF.h"
#include "PERI_PWM.h"
#include "PERI_QDC.h"
#include "PERI_RTC.h"
#include "PERI_S50.h"
#include "PERI_SCG.h"
#include "PERI_SMARTDMA.h"
#include "PERI_SPC.h"
#include "PERI_SYSCON.h"
#include "PERI_SYSPM.h"
#include "PERI_TRDC.h"
#include "PERI_USBHS.h"
#include "PERI_USBHSDCD.h"
#include "PERI_USBNC.h"
#include "PERI_USBPHY.h"
#include "PERI_UTICK.h"
#include "PERI_VBAT.h"
#include "PERI_VREF.h"
#include "PERI_WUU.h"
#include "PERI_WWDT.h"

#endif  /* #if !defined(MCXN236_H_) */
